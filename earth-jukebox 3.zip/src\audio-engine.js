/**
 * NASA Earth Jukebox - Web Audio API Real-Time Sonification Engine
 * Translates visual data (hue, saturation, luminance, coordinates) into rich musical soundscapes.
 */

export class EarthAudioEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.analyser = null;
    this.isMuted = false;
    this.currentSynth = 'ocean-drone';
    this.currentScale = 'lydian';
    this.activeVoices = [];
    this.isInitialized = false;

    // Recording state
    this.mediaRecorder = null;
    this.recordedChunks = [];
    this.isRecording = false;
    this.streamDestination = null;

    // Scale Definitions (Midi notes or frequency ratios based on C3 = 130.81Hz)
    this.scales = {
      'pentatonic-minor': [130.81, 155.56, 174.61, 196.00, 233.08, 261.63, 311.13, 349.23, 392.00, 466.16, 523.25], // C Eb F G Bb
      'lydian': [130.81, 146.83, 164.81, 185.00, 196.00, 220.00, 246.94, 261.63, 293.66, 329.63, 369.99, 392.00, 440.00, 523.25], // C D E F# G A B
      'dorian': [130.81, 146.83, 155.56, 174.61, 196.00, 220.00, 233.08, 261.63, 293.66, 311.13, 349.23, 392.00, 440.00, 523.25], // C D Eb F G A Bb
      'pentatonic-major': [130.81, 146.83, 164.81, 196.00, 220.00, 261.63, 293.66, 329.63, 392.00, 440.00, 523.25], // C D E G A
      'chromatic-tension': [130.81, 138.59, 146.83, 155.56, 164.81, 174.61, 185.00, 196.00, 207.65, 220.00, 233.08, 246.94, 261.63, 277.18, 293.66, 311.13, 329.63, 349.23, 369.99, 392.00, 415.30, 440.00, 466.16, 493.88, 523.25]
    };

    // Ambient Drone Nodes
    this.droneGain = null;
    this.droneOsc1 = null;
    this.droneOsc2 = null;
    this.droneFilter = null;
  }

  /**
   * Initializes Audio Context on first user gesture
   */
  async init() {
    if (this.isInitialized) return;

    const AudioContext = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AudioContext();

    // Master Gain
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(0.7, this.ctx.currentTime);

    // Analyser Node for Visualizers
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 256;
    this.analyser.smoothingTimeConstant = 0.85;

    // Stream destination for high-quality audio recording
    this.streamDestination = this.ctx.createMediaStreamDestination();

    // Reverb / Convolver Simulator using dynamic noise impulse
    this.reverbNode = this.createSyntheticReverb(2.5, 0.4);

    // Master bus wiring
    this.masterGain.connect(this.analyser);
    this.analyser.connect(this.ctx.destination);
    this.masterGain.connect(this.streamDestination);

    // Setup base ambient Earth drone
    this.initEarthDrone();

    this.isInitialized = true;
  }

  /**
   * Creates a synthetic impulse response for cosmic/ambient reverb
   */
  createSyntheticReverb(duration, decay) {
    const sampleRate = this.ctx.sampleRate;
    const length = sampleRate * duration;
    const impulse = this.ctx.createBuffer(2, length, sampleRate);
    const left = impulse.getChannelData(0);
    const right = impulse.getChannelData(1);

    for (let i = 0; i < length; i++) {
      const n = (length - i) / length;
      const factor = Math.pow(n, decay);
      left[i] = (Math.random() * 2 - 1) * factor;
      right[i] = (Math.random() * 2 - 1) * factor;
    }

    const convolver = this.ctx.createConvolver();
    convolver.buffer = impulse;

    // Reverb send/return gain
    this.reverbWet = this.ctx.createGain();
    this.reverbWet.gain.setValueAtTime(0.35, this.ctx.currentTime);
    convolver.connect(this.reverbWet);
    this.reverbWet.connect(this.masterGain);

    return convolver;
  }

  /**
   * Base Earth Drone (low-frequency planetary hum)
   */
  initEarthDrone() {
    this.droneFilter = this.ctx.createBiquadFilter();
    this.droneFilter.type = 'lowpass';
    this.droneFilter.frequency.setValueAtTime(180, this.ctx.currentTime);
    this.droneFilter.Q.setValueAtTime(3.0, this.ctx.currentTime);

    this.droneGain = this.ctx.createGain();
    this.droneGain.gain.setValueAtTime(0.12, this.ctx.currentTime);

    this.droneOsc1 = this.ctx.createOscillator();
    this.droneOsc1.type = 'sine';
    this.droneOsc1.frequency.setValueAtTime(65.41, this.ctx.currentTime); // C2

    this.droneOsc2 = this.ctx.createOscillator();
    this.droneOsc2.type = 'triangle';
    this.droneOsc2.frequency.setValueAtTime(65.90, this.ctx.currentTime); // Slight detune for phasing

    this.droneOsc1.connect(this.droneFilter);
    this.droneOsc2.connect(this.droneFilter);
    this.droneFilter.connect(this.droneGain);
    this.droneGain.connect(this.masterGain);

    this.droneOsc1.start();
    this.droneOsc2.start();
  }

  /**
   * Resume context if suspended
   */
  async ensureRunning() {
    if (!this.ctx) await this.init();
    if (this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }
  }

  /**
   * Map Color HSL & Luminance to Musical Pitch
   */
  getFrequencyForColor(hue, saturation, lightness, yPos = 0.5) {
    const scale = this.scales[this.currentScale] || this.scales['lydian'];

    // Map Hue (0 - 360) into scale index
    const normalizedHue = (hue % 360) / 360;
    const noteIndex = Math.floor(normalizedHue * scale.length) % scale.length;
    let baseFreq = scale[noteIndex];

    // Modulate octave based on vertical Y position (North = higher register, South = deeper)
    if (yPos < 0.3) {
      baseFreq *= 2; // North Pole / High Arctic treble
    } else if (yPos > 0.75) {
      baseFreq *= 0.5; // Antarctic / Abyss bass register
    }

    // Lightness adds slight shimmer / overtone offset
    if (lightness > 0.8) {
      baseFreq *= 1.5; // Fifth overtone for bright clouds/ice/cities
    }

    return baseFreq;
  }

  /**
   * Sonify an analyzed geographic column or regional slice
   */
  playSliceSonification(metrics, panX = 0) {
    if (!this.ctx || this.isMuted) return;

    const { dominantHue, saturation, luminance, density, highPoints = [] } = metrics;
    const now = this.ctx.currentTime;

    // Filter modulation based on overall luminance/brightness
    const targetCutoff = 400 + luminance * 4200;
    this.droneFilter.frequency.setTargetAtTime(Math.min(targetCutoff * 0.4, 600), now, 0.1);

    // Trigger synth note based on current synth style
    switch (this.currentSynth) {
      case 'ocean-drone':
        this.playOceanVoice(metrics, panX, now);
        break;
      case 'cosmic-ambient':
        this.playAmbientVoice(metrics, panX, now);
        break;
      case 'chime-marimba':
        this.playChimeVoice(metrics, panX, now);
        break;
      case 'cyber-pulse':
        this.playPulseVoice(metrics, panX, now);
        break;
      case 'solar-shimmer':
        this.playShimmerVoice(metrics, panX, now);
        break;
      default:
        this.playAmbientVoice(metrics, panX, now);
    }
  }

  /**
   * Voice 1: Ocean Drone (Sub-bass, sweeping bandpass swell, warmth)
   */
  playOceanVoice(metrics, panX, now) {
    const freq = this.getFrequencyForColor(metrics.dominantHue, metrics.saturation, metrics.luminance);

    const osc = this.ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, now);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(300 + metrics.luminance * 1800, now);
    filter.Q.setValueAtTime(4.0, now);

    const gain = this.ctx.createGain();
    const peakGain = 0.22 * (0.3 + metrics.density * 0.7);
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(peakGain, now + 0.12);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.65);

    const panner = this.createPanner(panX);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbNode);

    osc.start(now);
    osc.stop(now + 0.7);
  }

  /**
   * Voice 2: Cosmic Ambient (Sine/Tri chords + lush reverb)
   */
  playAmbientVoice(metrics, panX, now) {
    const scale = this.scales[this.currentScale] || this.scales['lydian'];
    const baseFreq = this.getFrequencyForColor(metrics.dominantHue, metrics.saturation, metrics.luminance);

    // Create 2-note harmonic dyad
    [1, 1.5].forEach((interval, idx) => {
      const osc = this.ctx.createOscillator();
      osc.type = idx === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(baseFreq * interval, now);

      const gain = this.ctx.createGain();
      const peak = (0.16 / (idx + 1)) * (0.4 + metrics.density * 0.6);
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.exponentialRampToValueAtTime(peak, now + 0.15 + idx * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.85);

      const panner = this.createPanner(panX + (idx === 0 ? -0.1 : 0.1));

      osc.connect(gain);
      gain.connect(panner);
      panner.connect(this.masterGain);
      panner.connect(this.reverbNode);

      osc.start(now);
      osc.stop(now + 0.9);
    });
  }

  /**
   * Voice 3: Chime Marimba (Percussive FM chime hits)
   */
  playChimeVoice(metrics, panX, now) {
    const baseFreq = this.getFrequencyForColor(metrics.dominantHue, metrics.saturation, metrics.luminance);

    // FM Carrier & Modulator
    const carrier = this.ctx.createOscillator();
    const modulator = this.ctx.createOscillator();
    const modGain = this.ctx.createGain();

    carrier.type = 'sine';
    carrier.frequency.setValueAtTime(baseFreq * 2, now);

    modulator.type = 'sine';
    modulator.frequency.setValueAtTime(baseFreq * 3.5, now);
    modGain.gain.setValueAtTime(baseFreq * (0.5 + metrics.saturation * 1.5), now);
    modGain.gain.exponentialRampToValueAtTime(1, now + 0.35);

    modulator.connect(modGain);
    modGain.connect(carrier.frequency);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.28, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);

    const panner = this.createPanner(panX);

    carrier.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbNode);

    modulator.start(now);
    carrier.start(now);
    modulator.stop(now + 0.5);
    carrier.stop(now + 0.5);
  }

  /**
   * Voice 4: Cyber Pulse (Analog 16th-note rhythmic arp)
   */
  playPulseVoice(metrics, panX, now) {
    const baseFreq = this.getFrequencyForColor(metrics.dominantHue, metrics.saturation, metrics.luminance);

    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(baseFreq, now);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    const cutoff = 600 + metrics.luminance * 3800;
    filter.frequency.setValueAtTime(cutoff, now);
    filter.frequency.exponentialRampToValueAtTime(200, now + 0.25);
    filter.Q.setValueAtTime(5.0, now);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.18, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.28);

    const panner = this.createPanner(panX);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.3);
  }

  /**
   * Voice 5: Solar Shimmer (High resonant ethereal harmonics)
   */
  playShimmerVoice(metrics, panX, now) {
    const baseFreq = this.getFrequencyForColor(metrics.dominantHue, metrics.saturation, metrics.luminance) * 2;

    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(baseFreq, now);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(800, now);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(0.15, now + 0.2);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.9);

    const panner = this.createPanner(panX);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbNode);

    osc.start(now);
    osc.stop(now + 0.95);
  }

  /**
   * Interactive Probe / Coordinate Hover note
   */
  playPointProbe(hue, sat, lum, xNorm, yNorm) {
    if (!this.ctx || this.isMuted) return;

    const now = this.ctx.currentTime;
    const panX = (xNorm - 0.5) * 2; // -1 (West) to +1 (East)
    const baseFreq = this.getFrequencyForColor(hue, sat, lum, yNorm);

    // Play pleasant crystal probe triad
    [1.0, 1.25, 1.5].forEach((ratio, i) => {
      const osc = this.ctx.createOscillator();
      osc.type = i === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(baseFreq * ratio, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.18 / (i + 1), now + 0.02 + i * 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.65);

      const panner = this.createPanner(panX);

      osc.connect(gain);
      gain.connect(panner);
      panner.connect(this.masterGain);
      panner.connect(this.reverbNode);

      osc.start(now);
      osc.stop(now + 0.7);
    });
  }

  /**
   * Helper to create Stereo Panner node safely
   */
  createPanner(panValue) {
    const clampedPan = Math.max(-1, Math.min(1, panValue));
    if (this.ctx.createStereoPanner) {
      const panner = this.ctx.createStereoPanner();
      panner.pan.setValueAtTime(clampedPan, this.ctx.currentTime);
      return panner;
    }
    // Fallback for older browsers
    return this.ctx.createGain();
  }

  /**
   * Set Master Volume (0.0 to 1.0)
   */
  setVolume(volume) {
    if (!this.masterGain || !this.ctx) return;
    this.masterGain.gain.setTargetAtTime(Math.max(0, Math.min(1, volume)), this.ctx.currentTime, 0.05);
  }

  /**
   * Toggle Mute
   */
  toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.isMuted ? 0 : 0.7, this.ctx.currentTime, 0.05);
    }
    return this.isMuted;
  }

  /**
   * Update Synth Type
   */
  setSynth(synthId) {
    this.currentSynth = synthId;
  }

  /**
   * Update Scale
   */
  setScale(scaleId) {
    if (this.scales[scaleId]) {
      this.currentScale = scaleId;
    }
  }

  /**
   * Start Live Audio Recording
   */
  startRecording() {
    if (!this.streamDestination || this.isRecording) return false;

    try {
      this.recordedChunks = [];
      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : 'audio/webm';

      this.mediaRecorder = new MediaRecorder(this.streamDestination.stream, { mimeType });

      this.mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          this.recordedChunks.push(e.data);
        }
      };

      this.mediaRecorder.start(200);
      this.isRecording = true;
      return true;
    } catch (err) {
      console.error('Failed to start recording:', err);
      return false;
    }
  }

  /**
   * Stop Live Audio Recording and return downloadable Blob URL
   */
  stopRecording() {
    return new Promise((resolve) => {
      if (!this.mediaRecorder || !this.isRecording) {
        resolve(null);
        return;
      }

      this.mediaRecorder.onstop = () => {
        this.isRecording = false;
        const blob = new Blob(this.recordedChunks, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        resolve({ blob, url });
      };

      this.mediaRecorder.stop();
    });
  }

  /**
   * Get FFT Spectrum Data for Visualizers
   */
  getFrequencyData(array) {
    if (this.analyser) {
      this.analyser.getByteFrequencyData(array);
    }
  }

  /**
   * Get Time-Domain Waveform Data for Oscilloscope
   */
  getTimeDomainData(array) {
    if (this.analyser) {
      this.analyser.getByteTimeDomainData(array);
    }
  }
}
