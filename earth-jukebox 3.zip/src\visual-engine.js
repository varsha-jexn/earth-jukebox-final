/**
 * NASA Earth Jukebox - Computer Vision & Visual Processing Engine
 * Analyzes visual frames, color spectra, pixel density, and coordinates in real-time.
 */

import { renderEICFrame } from './datasets.js';

export class EarthVisualEngine {
  constructor(canvasElement) {
    this.canvas = canvasElement;
    this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });

    // Offscreen analysis canvas for pixel reading
    this.offscreenCanvas = document.createElement('canvas');
    this.offCtx = this.offscreenCanvas.getContext('2d', { willReadFrequently: true });

    this.width = this.canvas.width;
    this.height = this.canvas.height;
    this.offscreenCanvas.width = this.width;
    this.offscreenCanvas.height = this.height;

    // Scan State
    this.scanMode = 'orbital'; // 'orbital' (horizontal), 'latitude' (vertical), 'probe' (interactive)
    this.scanPosition = 0.0; // 0.0 to 1.0
    this.scanSpeed = 0.0035; // Scan increment per animation frame
    this.isScanning = true;

    // Custom Uploaded Image
    this.customImage = null;
    this.isCustomImage = false;
  }

  resize(w, h) {
    this.width = w;
    this.height = h;
    this.canvas.width = w;
    this.canvas.height = h;
    this.offscreenCanvas.width = w;
    this.offscreenCanvas.height = h;
  }

  /**
   * Set custom user-uploaded satellite image
   */
  setCustomImage(img) {
    this.customImage = img;
    this.isCustomImage = true;
  }

  clearCustomImage() {
    this.customImage = null;
    this.isCustomImage = false;
  }

  /**
   * Render frame to canvas and update offscreen buffer
   */
  render(datasetId, frameIndex) {
    if (this.isCustomImage && this.customImage) {
      // Draw user's image
      this.ctx.drawImage(this.customImage, 0, 0, this.width, this.height);
      this.offCtx.drawImage(this.customImage, 0, 0, this.width, this.height);

      // Draw HUD and scan beam on user image
      if (this.isScanning) {
        this.drawScanBeam(this.ctx, this.scanPosition);
      }
    } else {
      // Draw procedural NASA EIC scientific frame
      renderEICFrame(this.offCtx, this.width, this.height, datasetId, frameIndex, null);
      renderEICFrame(this.ctx, this.width, this.height, datasetId, frameIndex, this.isScanning ? this.scanPosition : null);
    }
  }

  /**
   * Draw the visual scanline
   */
  drawScanBeam(ctx, pos) {
    const scanX = pos * this.width;
    ctx.save();
    const beamGrad = ctx.createLinearGradient(scanX - 20, 0, scanX + 20, 0);
    beamGrad.addColorStop(0, 'rgba(0, 240, 255, 0)');
    beamGrad.addColorStop(0.5, 'rgba(0, 240, 255, 0.4)');
    beamGrad.addColorStop(1, 'rgba(0, 240, 255, 0)');
    ctx.fillStyle = beamGrad;
    ctx.fillRect(scanX - 20, 0, 40, this.height);

    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 2;
    ctx.shadowColor = '#00f0ff';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.moveTo(scanX, 0);
    ctx.lineTo(scanX, this.height);
    ctx.stroke();
    ctx.restore();
  }

  /**
   * Advance Scan Position
   */
  tickScan(rateMultiplier = 1.0) {
    if (!this.isScanning) return;
    this.scanPosition += this.scanSpeed * rateMultiplier;
    if (this.scanPosition > 1.0) {
      this.scanPosition = 0.0;
    }
  }

  /**
   * Analyze the vertical slice under the current scan position
   * Returns musical and scientific metrics (dominant hue, saturation, luminance, density)
   */
  analyzeCurrentSlice() {
    const x = Math.min(this.width - 1, Math.max(0, Math.floor(this.scanPosition * this.width)));
    const sliceWidth = 4; // Sample a 4-pixel wide column
    const sampleX = Math.min(this.width - sliceWidth, Math.max(0, x - Math.floor(sliceWidth / 2)));

    let imgData;
    try {
      imgData = this.offCtx.getImageData(sampleX, 0, sliceWidth, this.height);
    } catch (e) {
      return null;
    }

    const data = imgData.data;
    const totalPixels = sliceWidth * this.height;

    let totalR = 0, totalG = 0, totalB = 0;
    let totalLum = 0;
    let highPoints = [];
    let activePixels = 0;

    // Step by 4 (RGBA) and skip every few rows for smooth 60fps performance
    const step = 8;
    let sampledCount = 0;

    for (let y = 0; y < this.height; y += step) {
      for (let px = 0; px < sliceWidth; px++) {
        const idx = (y * sliceWidth + px) * 4;
        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];

        // Standard relative luminance formula
        const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;

        totalR += r;
        totalG += g;
        totalB += b;
        totalLum += lum;
        sampledCount++;

        if (lum > 0.6) {
          activePixels++;
          if (highPoints.length < 5) {
            highPoints.push({ y: y / this.height, lum });
          }
        }
      }
    }

    const avgR = totalR / sampledCount;
    const avgG = totalG / sampledCount;
    const avgB = totalB / sampledCount;
    const avgLum = totalLum / sampledCount;
    const density = activePixels / sampledCount;

    const [hue, sat, lightness] = this.rgbToHsl(avgR, avgG, avgB);

    return {
      xPosition: this.scanPosition,
      panX: (this.scanPosition - 0.5) * 2, // -1 to +1
      dominantHue: hue,
      saturation: sat,
      luminance: avgLum,
      lightness: lightness,
      density: density,
      highPoints: highPoints,
      avgR, avgG, avgB
    };
  }

  /**
   * Analyze a single coordinate point (for mouse hover / interactive probe)
   */
  analyzePoint(clientX, clientY) {
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.width / rect.width;
    const scaleY = this.height / rect.height;

    const x = Math.floor((clientX - rect.left) * scaleX);
    const y = Math.floor((clientY - rect.top) * scaleY);

    if (x < 0 || x >= this.width || y < 0 || y >= this.height) return null;

    let p;
    try {
      p = this.offCtx.getImageData(x, y, 1, 1).data;
    } catch (e) {
      return null;
    }

    const r = p[0], g = p[1], b = p[2];
    const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    const [hue, sat, lightness] = this.rgbToHsl(r, g, b);

    // Convert pixel coordinates to geographic Lat/Long
    // Equirectangular: x from 0 to W is -180° to +180°, y from 0 to H is +90° to -90°
    const longitude = ((x / this.width) * 360 - 180).toFixed(1);
    const latitude = (90 - (y / this.height) * 180).toFixed(1);

    return {
      x, y,
      xNorm: x / this.width,
      yNorm: y / this.height,
      r, g, b,
      hue, sat, lightness, lum,
      latitude: `${Math.abs(latitude)}° ${latitude >= 0 ? 'N' : 'S'}`,
      longitude: `${Math.abs(longitude)}° ${longitude >= 0 ? 'E' : 'W'}`
    };
  }

  /**
   * Fast RGB to HSL conversion
   */
  rgbToHsl(r, g, b) {
    r /= 255;
    g /= 255;
    b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h, s, l = (max + min) / 2;

    if (max === min) {
      h = s = 0; // achromatic
    } else {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }

    return [Math.round(h * 360), s, l];
  }
}
