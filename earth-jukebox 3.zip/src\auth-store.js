/**
 * NASA Earth Jukebox - Client Authentication & User Profile Store
 * Provides persistent authentication, sign-up, login, and user favorites via localStorage.
 */

const STORAGE_KEY_USERS = 'earth_jukebox_users_v1';
const STORAGE_KEY_SESSION = 'earth_jukebox_current_session_v1';

// Default Demo User for immediate testing
const DEFAULT_DEMO_USER = {
  id: 'usr-nasa-001',
  name: 'Dr. Elena Vance',
  email: 'elena.vance@nasa.gov',
  password: 'earthscience2026',
  role: 'NASA Climate Sonification Fellow',
  avatar: 'EV',
  preferredSynth: 'ocean-drone',
  preferredScale: 'lydian',
  accessibility: {
    screenReaderAnnounce: true,
    highContrast: false,
    audioDescriptions: true
  },
  savedSoundscapes: [
    {
      id: 'fav-1',
      datasetId: 'sst-anomaly',
      title: 'Equatorial Pacific Heat Tongue',
      synth: 'ocean-drone',
      scale: 'lydian',
      savedAt: '2026-11-14T18:30:00Z'
    },
    {
      id: 'fav-2',
      datasetId: 'sea-ice-extent',
      title: 'Decadal Arctic Cryosphere Minimum',
      synth: 'chime-marimba',
      scale: 'dorian',
      savedAt: '2026-11-15T01:15:00Z'
    }
  ],
  customPresets: [
    {
      id: 'preset-deep-abyss',
      name: 'Abyssal Thermocline Harmonic',
      synth: 'ocean-drone',
      scale: 'dorian',
      scanRate: 0.8,
      volume: 0.85
    }
  ],
  history: [
    'Sonified Global Sea Surface Temperature (12 frames)',
    'Explored VIIRS Earth at Night Megalopolis grid'
  ]
};

export class AuthStore {
  constructor() {
    this.currentUser = null;
    this.listeners = [];
    this.init();
  }

  init() {
    // Check if users database exists, else initialize with demo user
    let users = this.getUsers();
    if (!users || users.length === 0) {
      users = [DEFAULT_DEMO_USER];
      this.saveUsers(users);
    }

    // Check active session
    try {
      const sessionData = localStorage.getItem(STORAGE_KEY_SESSION);
      if (sessionData) {
        const sessionUser = JSON.parse(sessionData);
        // Refresh with latest from user list
        const found = users.find(u => u.id === sessionUser.id);
        this.currentUser = found || sessionUser;
      }
    } catch (e) {
      console.error('Failed reading session', e);
      this.currentUser = null;
    }
  }

  getUsers() {
    try {
      const data = localStorage.getItem(STORAGE_KEY_USERS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }

  saveUsers(users) {
    localStorage.setItem(STORAGE_KEY_USERS, JSON.stringify(users));
  }

  subscribe(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  notify() {
    this.listeners.forEach(fn => fn(this.currentUser));
  }

  /**
   * Log In with Email and Password
   */
  login(email, password) {
    const users = this.getUsers();
    const cleanEmail = email.trim().toLowerCase();
    const user = users.find(u => u.email.toLowerCase() === cleanEmail);

    if (!user) {
      return { success: false, error: 'No account found with this email. Please check your credentials or Sign Up.' };
    }

    if (user.password !== password) {
      return { success: false, error: 'Incorrect password. Try again or use the Demo Login button.' };
    }

    // Session established
    this.currentUser = user;
    localStorage.setItem(STORAGE_KEY_SESSION, JSON.stringify(user));
    this.notify();
    return { success: true, user };
  }

  /**
   * Sign Up a new user
   */
  signup({ name, email, password, preferredSynth = 'ocean-drone', preferredScale = 'lydian', accessibility = {} }) {
    if (!name || name.trim().length < 2) {
      return { success: false, error: 'Please enter your full name.' };
    }
    if (!email || !email.includes('@') || !email.includes('.')) {
      return { success: false, error: 'Please enter a valid email address.' };
    }
    if (!password || password.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters long.' };
    }

    const users = this.getUsers();
    const cleanEmail = email.trim().toLowerCase();
    if (users.some(u => u.email.toLowerCase() === cleanEmail)) {
      return { success: false, error: 'An account with this email already exists. Please log in.' };
    }

    // Generate Initials Avatar
    const nameParts = name.trim().split(' ');
    const initials = (nameParts[0][0] + (nameParts.length > 1 ? nameParts[1][0] : '')).toUpperCase();

    const newUser = {
      id: `usr-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: name.trim(),
      email: cleanEmail,
      password,
      role: 'Earth Explorer & Sonification Artist',
      avatar: initials,
      preferredSynth,
      preferredScale,
      accessibility: {
        screenReaderAnnounce: !!accessibility.screenReaderAnnounce,
        highContrast: !!accessibility.highContrast,
        audioDescriptions: !!accessibility.audioDescriptions
      },
      savedSoundscapes: [],
      customPresets: [],
      history: [`Joined NASA Earth Jukebox on ${new Date().toLocaleDateString()}`]
    };

    users.push(newUser);
    this.saveUsers(users);

    // Auto-login newly created account
    this.currentUser = newUser;
    localStorage.setItem(STORAGE_KEY_SESSION, JSON.stringify(newUser));
    this.notify();

    return { success: true, user: newUser };
  }

  /**
   * Quick 1-click Demo Login
   */
  loginAsDemo() {
    return this.login('elena.vance@nasa.gov', 'earthscience2026');
  }

  /**
   * Log Out
   */
  logout() {
    this.currentUser = null;
    localStorage.removeItem(STORAGE_KEY_SESSION);
    this.notify();
  }

  /**
   * Save a soundscape to the user's library
   */
  saveFavorite(soundscape) {
    if (!this.currentUser) return false;

    const exists = this.currentUser.savedSoundscapes.some(s => s.id === soundscape.id || (s.datasetId === soundscape.datasetId && s.title === soundscape.title));
    if (exists) return true; // Already saved

    this.currentUser.savedSoundscapes.unshift({
      ...soundscape,
      id: soundscape.id || `fav-${Date.now()}`,
      savedAt: new Date().toISOString()
    });

    this.persistCurrentUser();
    this.notify();
    return true;
  }

  /**
   * Remove a saved soundscape
   */
  removeFavorite(soundscapeId) {
    if (!this.currentUser) return;
    this.currentUser.savedSoundscapes = this.currentUser.savedSoundscapes.filter(s => s.id !== soundscapeId);
    this.persistCurrentUser();
    this.notify();
  }

  /**
   * Save custom synth preset
   */
  savePreset(preset) {
    if (!this.currentUser) return false;

    this.currentUser.customPresets.unshift({
      ...preset,
      id: preset.id || `preset-${Date.now()}`,
      createdAt: new Date().toISOString()
    });

    this.persistCurrentUser();
    this.notify();
    return true;
  }

  /**
   * Log activity item
   */
  addHistory(entry) {
    if (!this.currentUser) return;
    this.currentUser.history.unshift(entry);
    if (this.currentUser.history.length > 20) {
      this.currentUser.history.pop();
    }
    this.persistCurrentUser();
  }

  persistCurrentUser() {
    if (!this.currentUser) return;
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === this.currentUser.id);
    if (index !== -1) {
      users[index] = this.currentUser;
      this.saveUsers(users);
    }
    localStorage.setItem(STORAGE_KEY_SESSION, JSON.stringify(this.currentUser));
  }
}
