/**
 * NASA Earth Jukebox - Standalone Universal Bundle
 * Works seamlessly both on http:// (local servers) and file:// (direct file double-click).
 * Zero CORS restrictions, zero dependencies.
 */

(function () {
  'use strict';

  // =========================================================================
  // 1. EIC Datasets & Procedural Satellite Frame Renderer
  // =========================================================================

  const EIC_DATASETS = [
    {
      id: 'sst-anomaly',
      title: 'Global Sea Surface Temperature & Ocean Currents',
      subtitle: 'Thermal anomalies tracking El Niño, La Niña, and oceanic heatwaves',
      mission: 'NASA Terra & Aqua / Copernicus Sentinel-3',
      instrument: 'MODIS & SLSTR Infrared Radiometers',
      timeRange: '12-Month Seasonal & Multi-Year Cycle',
      units: '°C Anomaly (-4°C to +4°C)',
      colorLegend: [
        { color: '#1d4ed8', label: '-4°C' },
        { color: '#06b6d4', label: '-2°C' },
        { color: '#10b981', label: '0°C (Normal)' },
        { color: '#f59e0b', label: '+2°C' },
        { color: '#ef4444', label: '+4°C (Severe Heatwave)' }
      ],
      scientificInsights: [
        'Oceans absorb over 90% of excess heat trapped by greenhouse gases.',
        'Marine heatwaves devastate coral reef ecosystems and trigger intense hurricane activity.',
        'The equatorial Pacific "warm tongue" oscillation alters global weather patterns and atmospheric circulation.'
      ],
      audioProfile: {
        defaultSynth: 'ocean-drone',
        recommendedScale: 'lydian',
        baseNote: 'C3',
        scanRate: 1.0,
        description: 'Deep resonant sub-frequencies for cold polar abysses; warm harmonic swells for equatorial current tongues; shimmering high pitches for marine heatwave pulses.'
      },
      totalFrames: 12,
      frameNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
      narrative: (frameIndex) => {
        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        const month = months[frameIndex % 12];
        return `Frame ${frameIndex + 1} (${month}): Oceanic thermal scan shows intensified equatorial Pacific warming with energetic heat exchange off the Gulf Stream and Kuroshio current.`;
      }
    },
    {
      id: 'atmospheric-co2',
      title: 'Atmospheric Carbon Dioxide & Emission Plumes',
      subtitle: 'Global CO2 concentrations from industrial emissions and plant respiration',
      mission: 'Orbiting Carbon Observatory-2 (OCO-2) & GEOS Model',
      instrument: 'Three-Band High-Resolution Spectrometer',
      timeRange: 'Annual Biosphere Respiration Cycle',
      units: 'ppm (390 to 425 ppm)',
      colorLegend: [
        { color: '#047857', label: '390 ppm (Active Sinks)' },
        { color: '#eab308', label: '405 ppm (Mid-Latitude Baseline)' },
        { color: '#ea580c', label: '415 ppm (Urban/Industrial Plume)' },
        { color: '#dc2626', label: '425+ ppm (Peak Concentration)' }
      ],
      scientificInsights: [
        'Atmospheric CO2 has surged past 420 ppm—the highest concentration in over 3 million years.',
        'The Northern Hemisphere "breathes" each year: forests draw down CO2 in summer and release it in winter.',
        'Industrial corridors over North America, Europe, and East Asia manifest as concentrated reddish acoustic plumes.'
      ],
      audioProfile: {
        defaultSynth: 'cyber-pulse',
        recommendedScale: 'chromatic-tension',
        baseNote: 'D3',
        scanRate: 1.2,
        description: 'Fast, rhythmic staccato pulses for dense industrial emissions; soaring tense chords reflect surging carbon concentrations across industrialized continents.'
      },
      totalFrames: 12,
      frameNames: ['Jan Peak Winter Plumes', 'Feb High Respiration', 'Mar Arctic Trap', 'Apr Spring Turn', 'May Forest Awakening', 'Jun Rapid Sinks', 'Jul Summer Minimum', 'Aug Northern Drawdown', 'Sep Fall Rebound', 'Oct Deciduous Drop', 'Nov Heating Cycle', 'Dec Winter Buildup'],
      narrative: (frameIndex) => {
        const phases = [
          'Winter stagnation: intense red CO2 accumulation across North American and Eurasian industrial hubs.',
          'Late winter: carbon concentrations pool in the Arctic basin.',
          'Early spring: northern boreal forests begin waking up from dormancy.',
          'Spring equinox: atmospheric CO2 begins noticeable seasonal inflection.',
          'Late spring: burgeoning photosynthesis begins absorbing gigatons of carbon.',
          'Early summer: strong green sink zones emerge across the boreal forest and Amazon.',
          'Mid-summer: global atmospheric CO2 dips to its annual minimum as plants breathe in.',
          'Late summer: peak photosynthetic drawdown across temperate deciduous forests.',
          'Early autumn: harvest and leaf senescence slow down carbon absorption.',
          'Autumn: microbial decomposition begins releasing stored carbon back to the air.',
          'Late autumn: heating and industrial combustion emissions ramp up across northern latitudes.',
          'Early winter: dense emission plumes reform over high-density population centers.'
        ];
        return phases[frameIndex % 12];
      }
    },
    {
      id: 'sea-ice-extent',
      title: 'Arctic & Antarctic Polar Sea Ice Extent',
      subtitle: 'Decadal satellite monitoring of Earth\'s shrinking polar cryosphere',
      mission: 'Nimbus-7, DMSP, AMSR-E, ICESat-2',
      instrument: 'Special Sensor Microwave Imager (SSM/I) & ATLAS Laser',
      timeRange: '1980 to 2024 Long-Term Cryosphere Trend',
      units: 'Million km² Ice Cover (3.5 to 16.5 M km²)',
      colorLegend: [
        { color: '#0f172a', label: 'Open Ocean (Deep Water)' },
        { color: '#0284c7', label: 'Marginal Ice Zone' },
        { color: '#38bdf8', label: 'First-Year Sea Ice' },
        { color: '#f8fafc', label: 'Perennial Multi-Year Pack Ice' }
      ],
      scientificInsights: [
        'Arctic sea ice is declining at a rate of 12.6% per decade relative to the 1981-2010 average.',
        'Loss of reflective white ice triggers the "ice-albedo feedback", causing polar waters to absorb more solar heat.',
        'Older, thicker multi-year ice has virtually disappeared, replaced by fragile seasonal first-year ice.'
      ],
      audioProfile: {
        defaultSynth: 'chime-marimba',
        recommendedScale: 'dorian',
        baseNote: 'E3',
        scanRate: 0.8,
        description: 'Crystalline, glassy bell strikes and high marimba harmonics for thick ice shelves, transitioning to muted, hollow low-frequency oceanic murmurs as ice retreats.'
      },
      totalFrames: 10,
      frameNames: ['1980 Baseline', '1985 Decade Start', '1990 Steady Extent', '1995 Initial Thinning', '2000 Accelerating Loss', '2005 Historic Minimums', '2012 Record Low', '2016 Winter Anomaly', '2020 Fragile Cover', '2024 Modern Cryosphere'],
      narrative: (frameIndex) => {
        const stages = [
          '1980: Robust multi-year Arctic pack ice spans over 7.8 million square kilometers in September.',
          '1985: Stable winter ice shelf with high acoustic density across the Beaufort Gyre.',
          '1990: Minor cyclical retreat with persistent thick ice hugging northern Greenland.',
          '1995: Measurable thinning begins in peripheral seas (Barents and Kara seas).',
          '2000: Multi-year ice thickness drops by over 30%, increasing acoustic volatility.',
          '2005: Significant summer melt window opens the Northern Sea Route.',
          '2012: Historic all-time record minimum Arctic ice extent of 3.41 million square kilometers.',
          '2016: Unprecedented winter heatwaves impede freeze-up, weakening harmonic resonance.',
          '2020: Second-lowest ice extent on record; extensive dark open water absorption.',
          '2024: Fragile young seasonal ice dominates; polar cryosphere sonification sounds hollow and sparse.'
        ];
        return stages[frameIndex % 10];
      }
    },
    {
      id: 'biosphere-ndvi',
      title: 'Global Biosphere & Normalized Difference Vegetation Index (NDVI)',
      subtitle: 'The living "pulse" of Earth\'s plant life and seasonal greening',
      mission: 'Terra & Aqua / Suomi NPP',
      instrument: 'MODIS & VIIRS Visible/Infrared Spectroradiometer',
      timeRange: '12-Month Continental Biosphere Pulse',
      units: 'NDVI Index (0.0 Desert / Water to 0.9 Lush Canopy)',
      colorLegend: [
        { color: '#d97706', label: '0.1 Arid / Desert' },
        { color: '#ca8a04', label: '0.3 Scrubland / Tundra' },
        { color: '#84cc16', label: '0.5 Grassland / Savanna' },
        { color: '#15803d', label: '0.7 Temperate Forest' },
        { color: '#052e16', label: '0.9 Dense Equatorial Rainforest' }
      ],
      scientificInsights: [
        'The biosphere acts as Earth\'s lungs, absorbing approximately 30% of anthropogenic carbon emissions.',
        'Seasonal green waves sweep northward from the equator into the Canadian and Siberian taiga every spring.',
        'Droughts, deforestation, and changing monsoon cycles noticeably alter vegetation acoustic rhythms.'
      ],
      audioProfile: {
        defaultSynth: 'cosmic-ambient',
        recommendedScale: 'pentatonic-major',
        baseNote: 'F3',
        scanRate: 0.9,
        description: 'Organic woodwind swells and vibrant pentatonic flutes; lush rainforests generate rich multi-tone chords, while arid deserts resonate in quiet, dry open intervals.'
      },
      totalFrames: 12,
      frameNames: ['Jan Winter Slumber', 'Feb Equatorial Green', 'Mar Vernal Awakening', 'Apr Temperate Budding', 'May Boreal Surge', 'Jun Peak Taiga Vitality', 'Jul Global Maximum', 'Aug Late Summer Canopy', 'Sep Autumn Transmutation', 'Oct Fall Foliage Descent', 'Nov Boreal Dormancy', 'Dec Solstice Calm'],
      narrative: (frameIndex) => {
        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        return `${months[frameIndex % 12]}: Continental plant biomass sweeps rhythmically; tropical rain belts over the Congo and Amazon emit strong melodic harmony.`;
      }
    },
    {
      id: 'earth-at-night',
      title: 'Earth at Night: Global Energy & Luminescence',
      subtitle: 'Human civilization footprint, electrical grids, and urban settlement',
      mission: 'Suomi NPP & NOAA-20',
      instrument: 'VIIRS Day/Night Band (DNB) Low-Light Sensor',
      timeRange: 'Global Nocturnal Energy Mapping',
      units: 'Radiance (nW/cm²/sr)',
      colorLegend: [
        { color: '#030712', label: 'Unlit Oceans & Remote Wilderness' },
        { color: '#1e3a8a', label: 'Offshore Energy & Fishing Fleets' },
        { color: '#f59e0b', label: 'Suburban Arteries & Towns' },
        { color: '#fef08a', label: 'Megacities & Dense Urban Centers' },
        { color: '#ffffff', label: 'Peak Luminescence (Metropolitan Cores)' }
      ],
      scientificInsights: [
        'Light pollution has increased by nearly 10% each year, impacting nocturnal ecosystems and stargazing.',
        'Satellite night imagery accurately tracks socioeconomic development, disaster power outages, and conflict zones.',
        'Stark acoustic contrasts separate glowing continental corridors from vast dark ocean and forest expanses.'
      ],
      audioProfile: {
        defaultSynth: 'cyber-pulse',
        recommendedScale: 'pentatonic-minor',
        baseNote: 'A2',
        scanRate: 1.1,
        description: 'Deep nocturnal silence punctuated by sparkling, electric arpeggios that burst with rapid percussive notes whenever the scanline strikes illuminated metropolitan clusters.'
      },
      totalFrames: 6,
      frameNames: ['Global Luminescence Map', 'Western Megalopolis Focus', 'European Interconnected Grid', 'East Asian Night Lights', 'Nile Delta & Middle East', 'Trans-Oceanic Shipping & Offshore Platforms'],
      narrative: (frameIndex) => {
        const views = [
          'Full planetary night scan: shimmering electrical networks trace continental coastlines and major transport arteries.',
          'North American grid: intense sonic cluster across the Boston-Washington megalopolis and Great Lakes.',
          'European constellation: continuous web of illuminated cities radiating from London, Paris, and the Rhine Valley.',
          'East Asian brilliance: hyper-dense acoustic spark showers over the Pearl River Delta, Tokyo, and Seoul.',
          'Nile river ribbon: brilliant linear streak of light cutting through the silent Egyptian desert.',
          'Offshore signatures: pinpoint harmonic bursts from oil platforms, gas flares, and squid fishing fleets.'
        ];
        return views[frameIndex % 6];
      }
    },
    {
      id: 'ozone-hole',
      title: 'Antarctic Ozone Layer & Stratospheric Recovery',
      subtitle: 'Tracking Montreal Protocol atmospheric healing and polar vortex chemistry',
      mission: 'Aura, Suomi NPP & Sentinel-5P',
      instrument: 'OMI & TROPOMI UV Spectrometer',
      timeRange: 'Springtime Polar Vortex Dynamics',
      units: 'Dobson Units (100 to 450 DU)',
      colorLegend: [
        { color: '#4c1d95', label: '< 150 DU (Severe Ozone Hole)' },
        { color: '#2563eb', label: '200 DU (Depletion Threshold)' },
        { color: '#06b6d4', label: '275 DU (Mid-Latitude Average)' },
        { color: '#eab308', label: '350 DU (Rich Stratosphere)' },
        { color: '#ef4444', label: '> 400 DU (Maximum Concentration Ring)' }
      ],
      scientificInsights: [
        'The 1987 Montreal Protocol banned chlorofluorocarbons (CFCs), preventing catastrophic UV exposure.',
        'The ozone hole forms each austral spring (September-October) as sunlight activates reactive chlorine in polar stratospheric clouds.',
        'The ozone layer is projected to recover to 1980 levels over Antarctica by approximately 2066.'
      ],
      audioProfile: {
        defaultSynth: 'solar-shimmer',
        recommendedScale: 'lydian',
        baseNote: 'G3',
        scanRate: 0.9,
        description: 'Eerie, suspended high-pass frequency hollows representing the depleted polar hole; surrounded by rich, triumphant harmonic fanfares of ozone-rich collar rings.'
      },
      totalFrames: 8,
      frameNames: ['August Vortex Formation', 'Early September Depletion', 'Late September Minimum', 'Peak October Hole', 'Late October Stretching', 'November Breakdown', 'December Healing', 'Summer Recovery Baseline'],
      narrative: (frameIndex) => {
        const phases = [
          'Austral winter cold stabilizes the polar stratospheric vortex; ozone hole begins forming.',
          'September dawn: solar UV rays trigger chlorine catalysts, carving a steep acoustic vacuum.',
          'Late September: ozone values plummet below 130 Dobson Units over the South Pole.',
          'October maximum extent: the ozone depletion area expands to encompass all of Antarctica.',
          'Late October: planetary atmospheric waves begin distorting and elongating the vortex.',
          'November warming: polar stratospheric clouds dissolve, shutting down catalytic destruction.',
          'Early December: ozone-rich sub-polar air masses surge inward, filling the acoustic hollow.',
          'Summer solstice: normal atmospheric equilibrium restored across the high southern latitudes.'
        ];
        return phases[frameIndex % 8];
      }
    }
  ];

  function renderEICFrame(ctx, width, height, datasetId, frameIndex, scanPosition = null) {
    ctx.fillStyle = '#030816';
    ctx.fillRect(0, 0, width, height);

    const dataset = EIC_DATASETS.find(d => d.id === datasetId) || EIC_DATASETS[0];
    const t = (frameIndex / (dataset.totalFrames || 1)) * Math.PI * 2;

    drawEarthBackground(ctx, width, height);

    switch (datasetId) {
      case 'sst-anomaly':
        drawSSTLayer(ctx, width, height, t, frameIndex);
        break;
      case 'atmospheric-co2':
        drawCO2Layer(ctx, width, height, t, frameIndex);
        break;
      case 'sea-ice-extent':
        drawSeaIceLayer(ctx, width, height, frameIndex, dataset.totalFrames);
        break;
      case 'biosphere-ndvi':
        drawNDVILayer(ctx, width, height, t, frameIndex);
        break;
      case 'earth-at-night':
        drawNightLightsLayer(ctx, width, height, frameIndex);
        break;
      case 'ozone-hole':
        drawOzoneLayer(ctx, width, height, t, frameIndex);
        break;
      default:
        drawSSTLayer(ctx, width, height, t, frameIndex);
    }

    drawScientificGrid(ctx, width, height);

    if (scanPosition !== null && scanPosition >= 0 && scanPosition <= 1) {
      drawScanBeam(ctx, width, height, scanPosition);
    }
  }

  function drawEarthBackground(ctx, w, h) {
    ctx.fillStyle = '#061633';
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#0f2942';
    drawContinents(ctx, w, h);
  }

  function drawContinents(ctx, w, h) {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(w * 0.12, h * 0.25);
    ctx.bezierCurveTo(w * 0.15, h * 0.18, w * 0.25, h * 0.15, w * 0.32, h * 0.22);
    ctx.bezierCurveTo(w * 0.28, h * 0.35, w * 0.24, h * 0.42, w * 0.22, h * 0.52);
    ctx.bezierCurveTo(w * 0.18, h * 0.55, w * 0.14, h * 0.45, w * 0.10, h * 0.38);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(w * 0.25, h * 0.52);
    ctx.bezierCurveTo(w * 0.35, h * 0.56, w * 0.38, h * 0.65, w * 0.32, h * 0.82);
    ctx.bezierCurveTo(w * 0.28, h * 0.90, w * 0.26, h * 0.80, w * 0.25, h * 0.68);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(w * 0.45, h * 0.22);
    ctx.bezierCurveTo(w * 0.52, h * 0.16, w * 0.70, h * 0.14, w * 0.85, h * 0.24);
    ctx.bezierCurveTo(w * 0.88, h * 0.38, w * 0.80, h * 0.48, w * 0.70, h * 0.46);
    ctx.bezierCurveTo(w * 0.62, h * 0.44, w * 0.56, h * 0.38, w * 0.50, h * 0.35);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(w * 0.47, h * 0.38);
    ctx.bezierCurveTo(w * 0.58, h * 0.40, w * 0.60, h * 0.55, w * 0.55, h * 0.75);
    ctx.bezierCurveTo(w * 0.48, h * 0.80, w * 0.44, h * 0.60, w * 0.42, h * 0.48);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.ellipse(w * 0.82, h * 0.72, w * 0.07, h * 0.08, 0.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.beginPath();
    ctx.rect(0, h * 0.90, w, h * 0.10);
    ctx.fill();

    ctx.beginPath();
    ctx.ellipse(w * 0.36, h * 0.16, w * 0.04, h * 0.06, 0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawSSTLayer(ctx, w, h, t, frameIndex) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';

    const oceanGrad = ctx.createLinearGradient(0, 0, 0, h);
    oceanGrad.addColorStop(0, 'rgba(30, 58, 138, 0.8)');
    oceanGrad.addColorStop(0.3, 'rgba(6, 182, 212, 0.5)');
    oceanGrad.addColorStop(0.5, 'rgba(239, 68, 68, 0.7)');
    oceanGrad.addColorStop(0.7, 'rgba(6, 182, 212, 0.5)');
    oceanGrad.addColorStop(1, 'rgba(30, 58, 138, 0.8)');
    ctx.fillStyle = oceanGrad;
    ctx.fillRect(0, 0, w, h);

    const elNinoPhase = Math.sin(t + 0.5) * 0.5 + 0.5;
    const tongueX = w * 0.15;
    const tongueY = h * 0.52;
    const tongueW = w * 0.35 + elNinoPhase * (w * 0.1);
    const tongueH = h * 0.08;

    const tongueGrad = ctx.createRadialGradient(
      tongueX + tongueW * 0.6, tongueY, 5,
      tongueX + tongueW * 0.5, tongueY, tongueW * 0.5
    );
    tongueGrad.addColorStop(0, `rgba(239, 68, 68, ${0.7 + elNinoPhase * 0.3})`);
    tongueGrad.addColorStop(0.5, `rgba(245, 158, 11, ${0.6 + elNinoPhase * 0.2})`);
    tongueGrad.addColorStop(1, 'rgba(245, 158, 11, 0)');

    ctx.fillStyle = tongueGrad;
    ctx.beginPath();
    ctx.ellipse(tongueX + tongueW * 0.5, tongueY, tongueW * 0.5, tongueH, 0, 0, Math.PI * 2);
    ctx.fill();

    const gulfGrad = ctx.createRadialGradient(w * 0.30, h * 0.35, 10, w * 0.34, h * 0.32, w * 0.15);
    gulfGrad.addColorStop(0, 'rgba(239, 68, 68, 0.7)');
    gulfGrad.addColorStop(0.6, 'rgba(245, 158, 11, 0.4)');
    gulfGrad.addColorStop(1, 'rgba(6, 182, 212, 0)');
    ctx.fillStyle = gulfGrad;
    ctx.beginPath();
    ctx.arc(w * 0.32, h * 0.34, w * 0.14, 0, Math.PI * 2);
    ctx.fill();

    const hotspots = [
      { x: w * 0.08, y: h * 0.38, r: w * 0.06 },
      { x: w * 0.65, y: h * 0.58, r: w * 0.08 },
      { x: w * 0.88, y: h * 0.68, r: w * 0.07 }
    ];

    hotspots.forEach((spot, i) => {
      const pulse = Math.sin(t + i * 2) * 0.2 + 0.8;
      const g = ctx.createRadialGradient(spot.x, spot.y, 2, spot.x, spot.y, spot.r * pulse);
      g.addColorStop(0, 'rgba(255, 255, 255, 0.8)');
      g.addColorStop(0.3, 'rgba(239, 68, 68, 0.7)');
      g.addColorStop(0.8, 'rgba(245, 158, 11, 0.3)');
      g.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(spot.x, spot.y, spot.r * pulse, 0, Math.PI * 2);
      ctx.fill();
    });

    ctx.restore();
  }

  function drawCO2Layer(ctx, w, h, t, frameIndex) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';

    const seasonalFactor = Math.sin(t - Math.PI / 4) * 0.5 + 0.5;

    const nhGrad = ctx.createLinearGradient(0, 0, 0, h * 0.6);
    nhGrad.addColorStop(0, `rgba(234, 88, 12, ${0.4 + seasonalFactor * 0.35})`);
    nhGrad.addColorStop(0.5, `rgba(234, 179, 8, ${0.3 + seasonalFactor * 0.2})`);
    nhGrad.addColorStop(1, 'rgba(4, 120, 87, 0.1)');
    ctx.fillStyle = nhGrad;
    ctx.fillRect(0, 0, w, h * 0.6);

    const plumes = [
      { x: w * 0.22, y: h * 0.34, rx: w * 0.09, ry: h * 0.08 },
      { x: w * 0.50, y: h * 0.28, rx: w * 0.08, ry: h * 0.07 },
      { x: w * 0.76, y: h * 0.35, rx: w * 0.12, ry: h * 0.09 },
      { x: w * 0.70, y: h * 0.45, rx: w * 0.06, ry: h * 0.06 }
    ];

    plumes.forEach((p, idx) => {
      const plumeIntensity = 0.5 + seasonalFactor * 0.4 + Math.sin(t * 2 + idx) * 0.1;
      const g = ctx.createRadialGradient(p.x, p.y, 5, p.x, p.y, p.rx);
      g.addColorStop(0, `rgba(220, 38, 38, ${plumeIntensity})`);
      g.addColorStop(0.4, `rgba(234, 88, 12, ${plumeIntensity * 0.8})`);
      g.addColorStop(0.8, `rgba(234, 179, 8, ${plumeIntensity * 0.4})`);
      g.addColorStop(1, 'rgba(0, 0, 0, 0)');

      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(p.x, p.y, p.rx, p.ry, 0, 0, Math.PI * 2);
      ctx.fill();
    });

    const southernBurnFactor = Math.cos(t) * 0.5 + 0.5;
    if (southernBurnFactor > 0.3) {
      const sPlumes = [
        { x: w * 0.30, y: h * 0.62, r: w * 0.07 },
        { x: w * 0.54, y: h * 0.60, r: w * 0.08 }
      ];
      sPlumes.forEach(sp => {
        const g = ctx.createRadialGradient(sp.x, sp.y, 4, sp.x, sp.y, sp.r * southernBurnFactor);
        g.addColorStop(0, `rgba(234, 88, 12, ${0.7 * southernBurnFactor})`);
        g.addColorStop(0.6, `rgba(234, 179, 8, ${0.4 * southernBurnFactor})`);
        g.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(sp.x, sp.y, sp.r * southernBurnFactor, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    ctx.restore();
  }

  function drawSeaIceLayer(ctx, w, h, frameIndex, totalFrames) {
    ctx.save();
    const lossProgress = frameIndex / (totalFrames - 1);
    const arcticShrink = 1.0 - lossProgress * 0.55;
    const antarcticMod = 1.0 - Math.sin(lossProgress * Math.PI) * 0.2;

    const arcticCenterX = w * 0.48;
    const arcticCenterY = h * 0.12;
    const arcticRadiusX = w * 0.28 * arcticShrink;
    const arcticRadiusY = h * 0.14 * arcticShrink;

    const iceGrad = ctx.createRadialGradient(
      arcticCenterX, arcticCenterY, 5,
      arcticCenterX, arcticCenterY, arcticRadiusX
    );
    iceGrad.addColorStop(0, '#ffffff');
    iceGrad.addColorStop(0.4, '#e0f2fe');
    iceGrad.addColorStop(0.8, '#38bdf8');
    iceGrad.addColorStop(1, 'rgba(2, 132, 199, 0)');

    ctx.fillStyle = iceGrad;
    ctx.beginPath();
    ctx.ellipse(arcticCenterX, arcticCenterY, arcticRadiusX, arcticRadiusY, 0, 0, Math.PI * 2);
    ctx.fill();

    const antarcticHeight = h * 0.15 * antarcticMod;
    const antGrad = ctx.createLinearGradient(0, h - antarcticHeight, 0, h);
    antGrad.addColorStop(0, 'rgba(56, 189, 248, 0)');
    antGrad.addColorStop(0.3, '#38bdf8');
    antGrad.addColorStop(0.7, '#e0f2fe');
    antGrad.addColorStop(1, '#ffffff');

    ctx.fillStyle = antGrad;
    ctx.fillRect(0, h - antarcticHeight, w, antarcticHeight);
    ctx.restore();
  }

  function drawNDVILayer(ctx, w, h, t, frameIndex) {
    ctx.save();
    ctx.globalCompositeOperation = 'source-over';

    const greenWave = Math.sin(t - Math.PI / 3) * 0.5 + 0.5;

    const amazonGrad = ctx.createRadialGradient(w * 0.30, h * 0.60, 10, w * 0.30, h * 0.60, w * 0.10);
    amazonGrad.addColorStop(0, '#052e16');
    amazonGrad.addColorStop(0.5, '#15803d');
    amazonGrad.addColorStop(0.9, '#84cc16');
    amazonGrad.addColorStop(1, 'rgba(132, 204, 22, 0)');
    ctx.fillStyle = amazonGrad;
    ctx.beginPath();
    ctx.arc(w * 0.30, h * 0.60, w * 0.10, 0, Math.PI * 2);
    ctx.fill();

    const congoGrad = ctx.createRadialGradient(w * 0.52, h * 0.55, 5, w * 0.52, h * 0.55, w * 0.07);
    congoGrad.addColorStop(0, '#052e16');
    congoGrad.addColorStop(0.6, '#15803d');
    congoGrad.addColorStop(1, 'rgba(21, 128, 61, 0)');
    ctx.fillStyle = congoGrad;
    ctx.beginPath();
    ctx.arc(w * 0.52, h * 0.55, w * 0.07, 0, Math.PI * 2);
    ctx.fill();

    const seaGrad = ctx.createRadialGradient(w * 0.78, h * 0.58, 5, w * 0.78, h * 0.58, w * 0.08);
    seaGrad.addColorStop(0, '#052e16');
    seaGrad.addColorStop(0.6, '#15803d');
    seaGrad.addColorStop(1, 'rgba(21, 128, 61, 0)');
    ctx.fillStyle = seaGrad;
    ctx.beginPath();
    ctx.arc(w * 0.78, h * 0.58, w * 0.08, 0, Math.PI * 2);
    ctx.fill();

    const taigaColor = greenWave > 0.5 ? '#15803d' : '#ca8a04';
    const taigaAlpha = 0.3 + greenWave * 0.5;

    ctx.fillStyle = taigaColor;
    ctx.globalAlpha = taigaAlpha;

    ctx.beginPath();
    ctx.ellipse(w * 0.22, h * 0.22, w * 0.12, h * 0.06, -0.1, 0, Math.PI * 2);
    ctx.fill();

    ctx.beginPath();
    ctx.ellipse(w * 0.65, h * 0.20, w * 0.22, h * 0.07, 0.05, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawNightLightsLayer(ctx, w, h, frameIndex) {
    ctx.save();
    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#090e24';
    drawContinents(ctx, w, h);

    const cities = [
      { x: w * 0.25, y: h * 0.33, r: 14 },
      { x: w * 0.21, y: h * 0.34, r: 10 },
      { x: w * 0.13, y: h * 0.37, r: 12 },
      { x: w * 0.19, y: h * 0.43, r: 8 },
      { x: w * 0.48, y: h * 0.28, r: 16 },
      { x: w * 0.52, y: h * 0.32, r: 10 },
      { x: w * 0.55, y: h * 0.24, r: 8 },
      { x: w * 0.77, y: h * 0.36, r: 16 },
      { x: w * 0.75, y: h * 0.42, r: 15 },
      { x: w * 0.85, y: h * 0.35, r: 14 },
      { x: w * 0.80, y: h * 0.34, r: 11 },
      { x: w * 0.68, y: h * 0.43, r: 13 },
      { x: w * 0.55, y: h * 0.43, r: 10 },
      { x: w * 0.60, y: h * 0.44, r: 11 },
      { x: w * 0.34, y: h * 0.72, r: 12 },
      { x: w * 0.30, y: h * 0.76, r: 9 },
      { x: w * 0.84, y: h * 0.75, r: 10 }
    ];

    ctx.globalCompositeOperation = 'screen';
    cities.forEach(city => {
      const g1 = ctx.createRadialGradient(city.x, city.y, 1, city.x, city.y, city.r * 2.5);
      g1.addColorStop(0, 'rgba(254, 240, 138, 0.9)');
      g1.addColorStop(0.3, 'rgba(245, 158, 11, 0.6)');
      g1.addColorStop(0.7, 'rgba(180, 83, 9, 0.2)');
      g1.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = g1;
      ctx.beginPath();
      ctx.arc(city.x, city.y, city.r * 2.5, 0, Math.PI * 2);
      ctx.fill();

      const g2 = ctx.createRadialGradient(city.x, city.y, 0, city.x, city.y, city.r * 0.7);
      g2.addColorStop(0, '#ffffff');
      g2.addColorStop(0.5, '#fef08a');
      g2.addColorStop(1, 'rgba(254, 240, 138, 0)');
      ctx.fillStyle = g2;
      ctx.beginPath();
      ctx.arc(city.x, city.y, city.r * 0.7, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();
  }

  function drawOzoneLayer(ctx, w, h, t, frameIndex) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';

    const collarGrad = ctx.createRadialGradient(w * 0.5, h * 0.85, w * 0.05, w * 0.5, h * 0.85, w * 0.35);
    collarGrad.addColorStop(0, 'rgba(76, 29, 149, 0)');
    collarGrad.addColorStop(0.35, 'rgba(6, 182, 212, 0.4)');
    collarGrad.addColorStop(0.65, 'rgba(234, 179, 8, 0.6)');
    collarGrad.addColorStop(0.85, 'rgba(239, 68, 68, 0.5)');
    collarGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = collarGrad;
    ctx.beginPath();
    ctx.arc(w * 0.5, h * 0.85, w * 0.35, 0, Math.PI * 2);
    ctx.fill();

    const holePhase = Math.sin(t) * 0.5 + 0.5;
    const holeRadius = w * 0.14 * (0.8 + holePhase * 0.4);

    const holeGrad = ctx.createRadialGradient(w * 0.5, h * 0.88, 5, w * 0.5, h * 0.88, holeRadius);
    holeGrad.addColorStop(0, '#4c1d95');
    holeGrad.addColorStop(0.6, '#312e81');
    holeGrad.addColorStop(0.85, '#1e3a8a');
    holeGrad.addColorStop(1, 'rgba(30, 58, 138, 0)');

    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = holeGrad;
    ctx.beginPath();
    ctx.ellipse(w * 0.5, h * 0.88, holeRadius, holeRadius * 0.75, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawScientificGrid(ctx, w, h) {
    ctx.save();
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.12)';
    ctx.lineWidth = 1;

    ctx.strokeStyle = 'rgba(56, 189, 248, 0.25)';
    ctx.beginPath();
    ctx.moveTo(0, h * 0.5);
    ctx.lineTo(w, h * 0.5);
    ctx.stroke();

    ctx.strokeStyle = 'rgba(56, 189, 248, 0.08)';
    [0.2, 0.35, 0.65, 0.8].forEach(latY => {
      ctx.beginPath();
      ctx.moveTo(0, h * latY);
      ctx.lineTo(w, h * latY);
      ctx.stroke();
    });

    for (let i = 1; i < 8; i++) {
      const longX = (w / 8) * i;
      ctx.beginPath();
      ctx.moveTo(longX, 0);
      ctx.lineTo(longX, h);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawScanBeam(ctx, w, h, scanPosition) {
    ctx.save();
    const scanX = scanPosition * w;

    const beamGrad = ctx.createLinearGradient(scanX - 25, 0, scanX + 25, 0);
    beamGrad.addColorStop(0, 'rgba(0, 240, 255, 0)');
    beamGrad.addColorStop(0.5, 'rgba(0, 240, 255, 0.45)');
    beamGrad.addColorStop(1, 'rgba(0, 240, 255, 0)');

    ctx.fillStyle = beamGrad;
    ctx.fillRect(scanX - 25, 0, 50, h);

    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 2;
    ctx.shadowColor = '#00f0ff';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.moveTo(scanX, 0);
    ctx.lineTo(scanX, h);
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(scanX, h * 0.5, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // =========================================================================
  // 2. Web Audio API Sonification Engine
  // =========================================================================

  class EarthAudioEngine {
    constructor() {
      this.ctx = null;
      this.masterGain = null;
      this.analyser = null;
      this.isMuted = false;
      this.currentSynth = 'ocean-drone';
      this.currentScale = 'lydian';
      this.isInitialized = false;

      this.mediaRecorder = null;
      this.recordedChunks = [];
      this.isRecording = false;
      this.streamDestination = null;

      this.scales = {
        'pentatonic-minor': [130.81, 155.56, 174.61, 196.00, 233.08, 261.63, 311.13, 349.23, 392.00, 466.16, 523.25],
        'lydian': [130.81, 146.83, 164.81, 185.00, 196.00, 220.00, 246.94, 261.63, 293.66, 329.63, 369.99, 392.00, 440.00, 523.25],
        'dorian': [130.81, 146.83, 155.56, 174.61, 196.00, 220.00, 233.08, 261.63, 293.66, 311.13, 349.23, 392.00, 440.00, 523.25],
        'pentatonic-major': [130.81, 146.83, 164.81, 196.00, 220.00, 261.63, 293.66, 329.63, 392.00, 440.00, 523.25],
        'chromatic-tension': [130.81, 138.59, 146.83, 155.56, 164.81, 174.61, 185.00, 196.00, 207.65, 220.00, 233.08, 246.94, 261.63, 277.18, 293.66, 311.13, 329.63, 349.23, 369.99, 392.00, 415.30, 440.00, 466.16, 493.88, 523.25]
      };
    }

    async init() {
      if (this.isInitialized) return;
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioCtx();

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.7, this.ctx.currentTime);

      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 256;
      this.analyser.smoothingTimeConstant = 0.85;

      this.streamDestination = this.ctx.createMediaStreamDestination();
      this.reverbNode = this.createSyntheticReverb(2.5, 0.4);

      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);
      this.masterGain.connect(this.streamDestination);

      this.initEarthDrone();
      this.isInitialized = true;
    }

    createSyntheticReverb(duration, decay) {
      const sampleRate = this.ctx.sampleRate;
      const length = sampleRate * duration;
      const impulse = this.ctx.createBuffer(2, length, sampleRate);
      const left = impulse.getChannelData(0);
      const right = impulse.getChannelData(1);

      for (let i = 0; i < length; i++) {
        const n = (length - i) / length;
        const factor = Math.pow(n, decay);
        left[i] = (Math.random() * 2 - 1) * factor;
        right[i] = (Math.random() * 2 - 1) * factor;
      }

      const convolver = this.ctx.createConvolver();
      convolver.buffer = impulse;

      this.reverbWet = this.ctx.createGain();
      this.reverbWet.gain.setValueAtTime(0.35, this.ctx.currentTime);
      convolver.connect(this.reverbWet);
      this.reverbWet.connect(this.masterGain);
      return convolver;
    }

    initEarthDrone() {
      this.droneFilter = this.ctx.createBiquadFilter();
      this.droneFilter.type = 'lowpass';
      this.droneFilter.frequency.setValueAtTime(180, this.ctx.currentTime);
      this.droneFilter.Q.setValueAtTime(3.0, this.ctx.currentTime);

      this.droneGain = this.ctx.createGain();
      this.droneGain.gain.setValueAtTime(0.12, this.ctx.currentTime);

      this.droneOsc1 = this.ctx.createOscillator();
      this.droneOsc1.type = 'sine';
      this.droneOsc1.frequency.setValueAtTime(65.41, this.ctx.currentTime);

      this.droneOsc2 = this.ctx.createOscillator();
      this.droneOsc2.type = 'triangle';
      this.droneOsc2.frequency.setValueAtTime(65.90, this.ctx.currentTime);

      this.droneOsc1.connect(this.droneFilter);
      this.droneOsc2.connect(this.droneFilter);
      this.droneFilter.connect(this.droneGain);
      this.droneGain.connect(this.masterGain);

      this.droneOsc1.start();
      this.droneOsc2.start();
    }

    async ensureRunning() {
      if (!this.ctx) await this.init();
      if (this.ctx.state === 'suspended') {
        await this.ctx.resume();
      }
    }

    getFrequencyForColor(hue, saturation, lightness, yPos = 0.5) {
      const scale = this.scales[this.currentScale] || this.scales['lydian'];
      const normalizedHue = (hue % 360) / 360;
      const noteIndex = Math.floor(normalizedHue * scale.length) % scale.length;
      let baseFreq = scale[noteIndex];

      if (yPos < 0.3) {
        baseFreq *= 2;
      } else if (yPos > 0.75) {
        baseFreq *= 0.5;
      }

      if (lightness > 0.8) {
        baseFreq *= 1.5;
      }
      return baseFreq;
    }

    playSliceSonification(metrics, panX = 0) {
      if (!this.ctx || this.isMuted) return;

      const now = this.ctx.currentTime;
      const targetCutoff = 400 + metrics.luminance * 4200;
      this.droneFilter.frequency.setTargetAtTime(Math.min(targetCutoff * 0.4, 600), now, 0.1);

      switch (this.currentSynth) {
        case 'ocean-drone':
          this.playOceanVoice(metrics, panX, now);
          break;
        case 'cosmic-ambient':
          this.playAmbientVoice(metrics, panX, now);
          break;
        case 'chime-marimba':
          this.playChimeVoice(metrics, panX, now);
          break;
        case 'cyber-pulse':
          this.playPulseVoice(metrics, panX, now);
          break;
        case 'solar-shimmer':
          this.playShimmerVoice(metrics, panX, now);
          break;
        default:
          this.playAmbientVoice(metrics, panX, now);
      }
    }

    playOceanVoice(metrics, panX, now) {
      const freq = this.getFrequencyForColor(metrics.dominantHue, metrics.saturation, metrics.luminance);

      const osc = this.ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(300 + metrics.luminance * 1800, now);
      filter.Q.setValueAtTime(4.0, now);

      const gain = this.ctx.createGain();
      const peakGain = 0.22 * (0.3 + metrics.density * 0.7);
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.exponentialRampToValueAtTime(peakGain, now + 0.12);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.65);

      const panner = this.createPanner(panX);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(panner);
      panner.connect(this.masterGain);
      panner.connect(this.reverbNode);

      osc.start(now);
      osc.stop(now + 0.7);
    }

    playAmbientVoice(metrics, panX, now) {
      const baseFreq = this.getFrequencyForColor(metrics.dominantHue, metrics.saturation, metrics.luminance);

      [1, 1.5].forEach((interval, idx) => {
        const osc = this.ctx.createOscillator();
        osc.type = idx === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(baseFreq * interval, now);

        const gain = this.ctx.createGain();
        const peak = (0.16 / (idx + 1)) * (0.4 + metrics.density * 0.6);
        gain.gain.setValueAtTime(0.001, now);
        gain.gain.exponentialRampToValueAtTime(peak, now + 0.15 + idx * 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.85);

        const panner = this.createPanner(panX + (idx === 0 ? -0.1 : 0.1));
        osc.connect(gain);
        gain.connect(panner);
        panner.connect(this.masterGain);
        panner.connect(this.reverbNode);

        osc.start(now);
        osc.stop(now + 0.9);
      });
    }

    playChimeVoice(metrics, panX, now) {
      const baseFreq = this.getFrequencyForColor(metrics.dominantHue, metrics.saturation, metrics.luminance);

      const carrier = this.ctx.createOscillator();
      const modulator = this.ctx.createOscillator();
      const modGain = this.ctx.createGain();

      carrier.type = 'sine';
      carrier.frequency.setValueAtTime(baseFreq * 2, now);
      modulator.type = 'sine';
      modulator.frequency.setValueAtTime(baseFreq * 3.5, now);
      modGain.gain.setValueAtTime(baseFreq * (0.5 + metrics.saturation * 1.5), now);
      modGain.gain.exponentialRampToValueAtTime(1, now + 0.35);

      modulator.connect(modGain);
      modGain.connect(carrier.frequency);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.28, now + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);

      const panner = this.createPanner(panX);
      carrier.connect(gain);
      gain.connect(panner);
      panner.connect(this.masterGain);
      panner.connect(this.reverbNode);

      modulator.start(now);
      carrier.start(now);
      modulator.stop(now + 0.5);
      carrier.stop(now + 0.5);
    }

    playPulseVoice(metrics, panX, now) {
      const baseFreq = this.getFrequencyForColor(metrics.dominantHue, metrics.saturation, metrics.luminance);

      const osc = this.ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(baseFreq, now);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      const cutoff = 600 + metrics.luminance * 3800;
      filter.frequency.setValueAtTime(cutoff, now);
      filter.frequency.exponentialRampToValueAtTime(200, now + 0.25);
      filter.Q.setValueAtTime(5.0, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.18, now + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.28);

      const panner = this.createPanner(panX);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(panner);
      panner.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.3);
    }

    playShimmerVoice(metrics, panX, now) {
      const baseFreq = this.getFrequencyForColor(metrics.dominantHue, metrics.saturation, metrics.luminance) * 2;

      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq, now);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.setValueAtTime(800, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.exponentialRampToValueAtTime(0.15, now + 0.2);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.9);

      const panner = this.createPanner(panX);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(panner);
      panner.connect(this.masterGain);
      panner.connect(this.reverbNode);

      osc.start(now);
      osc.stop(now + 0.95);
    }

    playPointProbe(hue, sat, lum, xNorm, yNorm) {
      if (!this.ctx || this.isMuted) return;

      const now = this.ctx.currentTime;
      const panX = (xNorm - 0.5) * 2;
      const baseFreq = this.getFrequencyForColor(hue, sat, lum, yNorm);

      [1.0, 1.25, 1.5].forEach((ratio, i) => {
        const osc = this.ctx.createOscillator();
        osc.type = i === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(baseFreq * ratio, now);

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.18 / (i + 1), now + 0.02 + i * 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.65);

        const panner = this.createPanner(panX);
        osc.connect(gain);
        gain.connect(panner);
        panner.connect(this.masterGain);
        panner.connect(this.reverbNode);

        osc.start(now);
        osc.stop(now + 0.7);
      });
    }

    createPanner(panValue) {
      const clampedPan = Math.max(-1, Math.min(1, panValue));
      if (this.ctx.createStereoPanner) {
        const panner = this.ctx.createStereoPanner();
        panner.pan.setValueAtTime(clampedPan, this.ctx.currentTime);
        return panner;
      }
      return this.ctx.createGain();
    }

    setVolume(volume) {
      if (!this.masterGain || !this.ctx) return;
      this.masterGain.gain.setTargetAtTime(Math.max(0, Math.min(1, volume)), this.ctx.currentTime, 0.05);
    }

    toggleMute() {
      this.isMuted = !this.isMuted;
      if (this.masterGain && this.ctx) {
        this.masterGain.gain.setTargetAtTime(this.isMuted ? 0 : 0.7, this.ctx.currentTime, 0.05);
      }
      return this.isMuted;
    }

    setSynth(synthId) {
      this.currentSynth = synthId;
    }

    setScale(scaleId) {
      if (this.scales[scaleId]) {
        this.currentScale = scaleId;
      }
    }

    startRecording() {
      if (!this.streamDestination || this.isRecording) return false;
      try {
        this.recordedChunks = [];
        const mimeType = (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported('audio/webm;codecs=opus'))
          ? 'audio/webm;codecs=opus'
          : 'audio/webm';

        this.mediaRecorder = new MediaRecorder(this.streamDestination.stream, { mimeType });
        this.mediaRecorder.ondataavailable = (e) => {
          if (e.data.size > 0) this.recordedChunks.push(e.data);
        };
        this.mediaRecorder.start(200);
        this.isRecording = true;
        return true;
      } catch (err) {
        console.error('Failed to start recording:', err);
        return false;
      }
    }

    stopRecording() {
      return new Promise((resolve) => {
        if (!this.mediaRecorder || !this.isRecording) {
          resolve(null);
          return;
        }
        this.mediaRecorder.onstop = () => {
          this.isRecording = false;
          const blob = new Blob(this.recordedChunks, { type: 'audio/webm' });
          const url = URL.createObjectURL(blob);
          resolve({ blob, url });
        };
        this.mediaRecorder.stop();
      });
    }

    getFrequencyData(array) {
      if (this.analyser) {
        this.analyser.getByteFrequencyData(array);
      }
    }

    getTimeDomainData(array) {
      if (this.analyser) {
        this.analyser.getByteTimeDomainData(array);
      }
    }
  }

  // =========================================================================
  // 3. Computer Vision & Canvas Visual Processing Engine
  // =========================================================================

  class EarthVisualEngine {
    constructor(canvasElement) {
      this.canvas = canvasElement;
      this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });

      this.offscreenCanvas = document.createElement('canvas');
      this.offCtx = this.offscreenCanvas.getContext('2d', { willReadFrequently: true });

      this.width = this.canvas.width;
      this.height = this.canvas.height;
      this.offscreenCanvas.width = this.width;
      this.offscreenCanvas.height = this.height;

      this.scanMode = 'orbital';
      this.scanPosition = 0.0;
      this.scanSpeed = 0.0035;
      this.isScanning = true;

      this.customImage = null;
      this.isCustomImage = false;
    }

    resize(w, h) {
      this.width = w;
      this.height = h;
      this.canvas.width = w;
      this.canvas.height = h;
      this.offscreenCanvas.width = w;
      this.offscreenCanvas.height = h;
    }

    setCustomImage(img) {
      this.customImage = img;
      this.isCustomImage = true;
    }

    clearCustomImage() {
      this.customImage = null;
      this.isCustomImage = false;
    }

    render(datasetId, frameIndex) {
      if (this.isCustomImage && this.customImage) {
        this.ctx.drawImage(this.customImage, 0, 0, this.width, this.height);
        this.offCtx.drawImage(this.customImage, 0, 0, this.width, this.height);

        if (this.isScanning) {
          this.drawScanBeam(this.ctx, this.scanPosition);
        }
      } else {
        renderEICFrame(this.offCtx, this.width, this.height, datasetId, frameIndex, null);
        renderEICFrame(this.ctx, this.width, this.height, datasetId, frameIndex, this.isScanning ? this.scanPosition : null);
      }
    }

    drawScanBeam(ctx, pos) {
      const scanX = pos * this.width;
      ctx.save();
      const beamGrad = ctx.createLinearGradient(scanX - 20, 0, scanX + 20, 0);
      beamGrad.addColorStop(0, 'rgba(0, 240, 255, 0)');
      beamGrad.addColorStop(0.5, 'rgba(0, 240, 255, 0.4)');
      beamGrad.addColorStop(1, 'rgba(0, 240, 255, 0)');
      ctx.fillStyle = beamGrad;
      ctx.fillRect(scanX - 20, 0, 40, this.height);

      ctx.strokeStyle = '#00f0ff';
      ctx.lineWidth = 2;
      ctx.shadowColor = '#00f0ff';
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.moveTo(scanX, 0);
      ctx.lineTo(scanX, this.height);
      ctx.stroke();
      ctx.restore();
    }

    tickScan(rateMultiplier = 1.0) {
      if (!this.isScanning) return;
      this.scanPosition += this.scanSpeed * rateMultiplier;
      if (this.scanPosition > 1.0) {
        this.scanPosition = 0.0;
      }
    }

    analyzeCurrentSlice() {
      const x = Math.min(this.width - 1, Math.max(0, Math.floor(this.scanPosition * this.width)));
      const sliceWidth = 4;
      const sampleX = Math.min(this.width - sliceWidth, Math.max(0, x - Math.floor(sliceWidth / 2)));

      let imgData;
      try {
        imgData = this.offCtx.getImageData(sampleX, 0, sliceWidth, this.height);
      } catch (e) {
        return null;
      }

      const data = imgData.data;
      let totalR = 0, totalG = 0, totalB = 0;
      let totalLum = 0;
      let highPoints = [];
      let activePixels = 0;

      const step = 8;
      let sampledCount = 0;

      for (let y = 0; y < this.height; y += step) {
        for (let px = 0; px < sliceWidth; px++) {
          const idx = (y * sliceWidth + px) * 4;
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];
          const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;

          totalR += r;
          totalG += g;
          totalB += b;
          totalLum += lum;
          sampledCount++;

          if (lum > 0.6) {
            activePixels++;
            if (highPoints.length < 5) {
              highPoints.push({ y: y / this.height, lum });
            }
          }
        }
      }

      const avgR = totalR / sampledCount;
      const avgG = totalG / sampledCount;
      const avgB = totalB / sampledCount;
      const avgLum = totalLum / sampledCount;
      const density = activePixels / sampledCount;

      const [hue, sat, lightness] = this.rgbToHsl(avgR, avgG, avgB);

      return {
        xPosition: this.scanPosition,
        panX: (this.scanPosition - 0.5) * 2,
        dominantHue: hue,
        saturation: sat,
        luminance: avgLum,
        lightness: lightness,
        density: density,
        highPoints: highPoints,
        avgR, avgG, avgB
      };
    }

    analyzePoint(clientX, clientY) {
      const rect = this.canvas.getBoundingClientRect();
      const scaleX = this.width / rect.width;
      const scaleY = this.height / rect.height;

      const x = Math.floor((clientX - rect.left) * scaleX);
      const y = Math.floor((clientY - rect.top) * scaleY);

      if (x < 0 || x >= this.width || y < 0 || y >= this.height) return null;

      let p;
      try {
        p = this.offCtx.getImageData(x, y, 1, 1).data;
      } catch (e) {
        return null;
      }

      const r = p[0], g = p[1], b = p[2];
      const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
      const [hue, sat, lightness] = this.rgbToHsl(r, g, b);

      const longitude = ((x / this.width) * 360 - 180).toFixed(1);
      const latitude = (90 - (y / this.height) * 180).toFixed(1);

      return {
        x, y,
        xNorm: x / this.width,
        yNorm: y / this.height,
        r, g, b,
        hue, sat, lightness, lum,
        latitude: `${Math.abs(latitude)}° ${latitude >= 0 ? 'N' : 'S'}`,
        longitude: `${Math.abs(longitude)}° ${longitude >= 0 ? 'E' : 'W'}`
      };
    }

    rgbToHsl(r, g, b) {
      r /= 255;
      g /= 255;
      b /= 255;
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      let h, s, l = (max + min) / 2;

      if (max === min) {
        h = s = 0;
      } else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case r: h = (g - b) / d + (g < b ? 6 : 0); break;
          case g: h = (b - r) / d + 2; break;
          case b: h = (r - g) / d + 4; break;
        }
        h /= 6;
      }

      return [Math.round(h * 360), s, l];
    }
  }

  // =========================================================================
  // 4. Client Authentication & Local Storage System
  // =========================================================================

  const STORAGE_KEY_USERS = 'earth_jukebox_users_v1';
  const STORAGE_KEY_SESSION = 'earth_jukebox_current_session_v1';

  const DEFAULT_DEMO_USER = {
    id: 'usr-nasa-001',
    name: 'Dr. Elena Vance',
    email: 'elena.vance@nasa.gov',
    password: 'earthscience2026',
    role: 'NASA Climate Sonification Fellow',
    avatar: 'EV',
    preferredSynth: 'ocean-drone',
    preferredScale: 'lydian',
    accessibility: {
      screenReaderAnnounce: true,
      highContrast: false,
      audioDescriptions: true
    },
    savedSoundscapes: [
      {
        id: 'fav-1',
        datasetId: 'sst-anomaly',
        title: 'Equatorial Pacific Heat Tongue',
        synth: 'ocean-drone',
        scale: 'lydian',
        savedAt: '2026-11-14T18:30:00Z'
      },
      {
        id: 'fav-2',
        datasetId: 'sea-ice-extent',
        title: 'Decadal Arctic Cryosphere Minimum',
        synth: 'chime-marimba',
        scale: 'dorian',
        savedAt: '2026-11-15T01:15:00Z'
      }
    ],
    customPresets: [
      {
        id: 'preset-deep-abyss',
        name: 'Abyssal Thermocline Harmonic',
        synth: 'ocean-drone',
        scale: 'dorian',
        scanRate: 0.8,
        volume: 0.85
      }
    ],
    history: [
      'Sonified Global Sea Surface Temperature (12 frames)',
      'Explored VIIRS Earth at Night Megalopolis grid'
    ]
  };

  class AuthStore {
    constructor() {
      this.currentUser = null;
      this.listeners = [];
      this.init();
    }

    init() {
      let users = this.getUsers();
      if (!users || users.length === 0) {
        users = [DEFAULT_DEMO_USER];
        this.saveUsers(users);
      }

      try {
        const sessionData = localStorage.getItem(STORAGE_KEY_SESSION);
        if (sessionData) {
          const sessionUser = JSON.parse(sessionData);
          const found = users.find(u => u.id === sessionUser.id);
          this.currentUser = found || sessionUser;
        }
      } catch (e) {
        this.currentUser = null;
      }
    }

    getUsers() {
      try {
        const data = localStorage.getItem(STORAGE_KEY_USERS);
        return data ? JSON.parse(data) : [];
      } catch (e) {
        return [];
      }
    }

    saveUsers(users) {
      try {
        localStorage.setItem(STORAGE_KEY_USERS, JSON.stringify(users));
      } catch (e) {}
    }

    subscribe(listener) {
      this.listeners.push(listener);
      return () => {
        this.listeners = this.listeners.filter(l => l !== listener);
      };
    }

    notify() {
      this.listeners.forEach(fn => fn(this.currentUser));
    }

    login(email, password) {
      const users = this.getUsers();
      const cleanEmail = email.trim().toLowerCase();
      const user = users.find(u => u.email.toLowerCase() === cleanEmail);

      if (!user) {
        return { success: false, error: 'No account found with this email. Please check your credentials or Sign Up.' };
      }

      if (user.password !== password) {
        return { success: false, error: 'Incorrect password. Try again or use the Demo Login button.' };
      }

      this.currentUser = user;
      try {
        localStorage.setItem(STORAGE_KEY_SESSION, JSON.stringify(user));
      } catch (e) {}
      this.notify();
      return { success: true, user };
    }

    signup({ name, email, password, preferredSynth = 'ocean-drone', preferredScale = 'lydian', accessibility = {} }) {
      if (!name || name.trim().length < 2) {
        return { success: false, error: 'Please enter your full name.' };
      }
      if (!email || !email.includes('@') || !email.includes('.')) {
        return { success: false, error: 'Please enter a valid email address.' };
      }
      if (!password || password.length < 6) {
        return { success: false, error: 'Password must be at least 6 characters long.' };
      }

      const users = this.getUsers();
      const cleanEmail = email.trim().toLowerCase();
      if (users.some(u => u.email.toLowerCase() === cleanEmail)) {
        return { success: false, error: 'An account with this email already exists. Please log in.' };
      }

      const nameParts = name.trim().split(' ');
      const initials = (nameParts[0][0] + (nameParts.length > 1 ? nameParts[1][0] : '')).toUpperCase();

      const newUser = {
        id: `usr-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        name: name.trim(),
        email: cleanEmail,
        password,
        role: 'Earth Explorer & Sonification Artist',
        avatar: initials,
        preferredSynth,
        preferredScale,
        accessibility: {
          screenReaderAnnounce: !!accessibility.screenReaderAnnounce,
          highContrast: !!accessibility.highContrast,
          audioDescriptions: !!accessibility.audioDescriptions
        },
        savedSoundscapes: [],
        customPresets: [],
        history: [`Joined NASA Earth Jukebox on ${new Date().toLocaleDateString()}`]
      };

      users.push(newUser);
      this.saveUsers(users);

      this.currentUser = newUser;
      try {
        localStorage.setItem(STORAGE_KEY_SESSION, JSON.stringify(newUser));
      } catch (e) {}
      this.notify();

      return { success: true, user: newUser };
    }

    loginAsDemo() {
      return this.login('elena.vance@nasa.gov', 'earthscience2026');
    }

    logout() {
      this.currentUser = null;
      try {
        localStorage.removeItem(STORAGE_KEY_SESSION);
      } catch (e) {}
      this.notify();
    }

    saveFavorite(soundscape) {
      if (!this.currentUser) return false;
      const exists = this.currentUser.savedSoundscapes.some(s => s.id === soundscape.id || (s.datasetId === soundscape.datasetId && s.title === soundscape.title));
      if (exists) return true;

      this.currentUser.savedSoundscapes.unshift({
        ...soundscape,
        id: soundscape.id || `fav-${Date.now()}`,
        savedAt: new Date().toISOString()
      });

      this.persistCurrentUser();
      this.notify();
      return true;
    }

    removeFavorite(soundscapeId) {
      if (!this.currentUser) return;
      this.currentUser.savedSoundscapes = this.currentUser.savedSoundscapes.filter(s => s.id !== soundscapeId);
      this.persistCurrentUser();
      this.notify();
    }

    addHistory(entry) {
      if (!this.currentUser) return;
      this.currentUser.history.unshift(entry);
      if (this.currentUser.history.length > 20) {
        this.currentUser.history.pop();
      }
      this.persistCurrentUser();
    }

    persistCurrentUser() {
      if (!this.currentUser) return;
      const users = this.getUsers();
      const index = users.findIndex(u => u.id === this.currentUser.id);
      if (index !== -1) {
        users[index] = this.currentUser;
        this.saveUsers(users);
      }
      try {
        localStorage.setItem(STORAGE_KEY_SESSION, JSON.stringify(this.currentUser));
      } catch (e) {}
    }
  }

  // =========================================================================
  // 5. Accessibility & Screen Reader / TTS Service
  // =========================================================================

  class AccessibilityService {
    constructor() {
      this.speechSynth = window.speechSynthesis || null;
      this.isTTSActive = false;
      this.isHighContrast = false;
      this.announcerElement = null;
      this.initAnnouncer();
    }

    initAnnouncer() {
      let el = document.getElementById('sr-announcements');
      if (!el) {
        el = document.createElement('div');
        el.id = 'sr-announcements';
        el.setAttribute('aria-live', 'polite');
        el.setAttribute('aria-atomic', 'true');
        el.className = 'sr-only';
        document.body.appendChild(el);
      }
      this.announcerElement = el;
    }

    announce(message, priority = 'polite') {
      if (!this.announcerElement) return;
      this.announcerElement.setAttribute('aria-live', priority);
      this.announcerElement.textContent = '';
      setTimeout(() => {
        this.announcerElement.textContent = message;
      }, 50);
    }

    speak(text, interrupt = false) {
      if (!this.speechSynth || !this.isTTSActive) return;

      if (interrupt) {
        this.speechSynth.cancel();
      }

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      utterance.volume = 0.9;

      const voices = this.speechSynth.getVoices();
      const preferredVoice = voices.find(v => v.lang && v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Siri')));
      if (preferredVoice) utterance.voice = preferredVoice;

      this.speechSynth.speak(utterance);
    }

    stopSpeaking() {
      if (this.speechSynth) {
        this.speechSynth.cancel();
      }
    }

    setTTS(active) {
      this.isTTSActive = active;
      if (!active) this.stopSpeaking();
    }

    toggleHighContrast() {
      this.isHighContrast = !this.isHighContrast;
      document.body.classList.toggle('high-contrast-mode', this.isHighContrast);
      this.announce(`High contrast mode ${this.isHighContrast ? 'activated' : 'deactivated'}`);
      return this.isHighContrast;
    }

    setHighContrast(enabled) {
      this.isHighContrast = enabled;
      document.body.classList.toggle('high-contrast-mode', this.isHighContrast);
    }
  }

  // =========================================================================
  // 6. Master Application Controller
  // =========================================================================

  class EarthJukeboxApp {
    constructor() {
      this.audio = new EarthAudioEngine();
      this.auth = new AuthStore();
      this.a11y = new AccessibilityService();

      this.currentDataset = EIC_DATASETS[0];
      this.currentFrameIndex = 0;
      this.isPlayingFrames = false;
      this.frameTimer = null;
      this.frameSpeedMs = 1200;
      this.isSonifying = false;
      this.scanSpeedMultiplier = 1.0;

      this.recordingInterval = null;
      this.recordingSeconds = 0;

      this.mainCanvas = document.getElementById('earth-canvas');
      this.scopeCanvas = document.getElementById('oscilloscope-canvas');
      this.spectrumCanvas = document.getElementById('spectrum-canvas');
      this.starCanvas = document.getElementById('stars-canvas');

      this.visual = new EarthVisualEngine(this.mainCanvas);

      this.scopeCtx = this.scopeCanvas ? this.scopeCanvas.getContext('2d') : null;
      this.spectrumCtx = this.spectrumCanvas ? this.spectrumCanvas.getContext('2d') : null;
      this.starCtx = this.starCanvas ? this.starCanvas.getContext('2d') : null;

      this.stars = [];
      this.initStarfield();

      this.freqData = new Uint8Array(64);
      this.timeData = new Uint8Array(128);

      this.lastAudioTriggerTime = 0;
      this.audioTriggerInterval = 120;

      this.init();
    }

    async init() {
      this.setupEventListeners();
      this.setupAuthListeners();
      this.setupDatasetList();
      this.loadDataset(this.currentDataset.id);
      this.resizeCanvases();
      window.addEventListener('resize', () => this.resizeCanvases());

      requestAnimationFrame((t) => this.animationLoop(t));
    }

    initStarfield() {
      if (!this.starCanvas) return;
      this.starCanvas.width = window.innerWidth;
      this.starCanvas.height = window.innerHeight;
      this.stars = [];
      const count = Math.floor((window.innerWidth * window.innerHeight) / 9000);
      for (let i = 0; i < count; i++) {
        this.stars.push({
          x: Math.random() * window.innerWidth,
          y: Math.random() * window.innerHeight,
          r: Math.random() * 1.5 + 0.4,
          alpha: Math.random() * 0.8 + 0.2,
          twinkleSpeed: Math.random() * 0.02 + 0.005
        });
      }
    }

    resizeCanvases() {
      if (this.starCanvas) {
        this.starCanvas.width = window.innerWidth;
        this.starCanvas.height = window.innerHeight;
      }

      const container = document.getElementById('canvas-wrapper');
      if (container && this.mainCanvas) {
        const rect = container.getBoundingClientRect();
        const w = Math.floor(rect.width);
        const h = Math.floor(rect.height);
        this.visual.resize(w, h);
      }

      if (this.scopeCanvas) {
        this.scopeCanvas.width = this.scopeCanvas.parentElement.clientWidth;
        this.scopeCanvas.height = 70;
      }
      if (this.spectrumCanvas) {
        this.spectrumCanvas.width = this.spectrumCanvas.parentElement.clientWidth;
        this.spectrumCanvas.height = 70;
      }
    }

    animationLoop(timestamp) {
      this.renderStars();

      if (this.isSonifying) {
        this.visual.tickScan(this.scanSpeedMultiplier);
      }
      this.visual.render(this.currentDataset.id, this.currentFrameIndex);

      if (this.isSonifying && timestamp - this.lastAudioTriggerTime > this.audioTriggerInterval) {
        const sliceMetrics = this.visual.analyzeCurrentSlice();
        if (sliceMetrics) {
          this.audio.playSliceSonification(sliceMetrics, sliceMetrics.panX);
          this.updateHUDMetrics(sliceMetrics);
        }
        this.lastAudioTriggerTime = timestamp;
      }

      this.renderAudioVisualizers();
      requestAnimationFrame((t) => this.animationLoop(t));
    }

    renderStars() {
      if (!this.starCtx || !this.starCanvas) return;
      this.starCtx.clearRect(0, 0, this.starCanvas.width, this.starCanvas.height);

      for (let s of this.stars) {
        s.alpha += Math.sin(Date.now() * s.twinkleSpeed) * 0.01;
        const a = Math.max(0.1, Math.min(0.9, s.alpha));
        this.starCtx.fillStyle = `rgba(224, 242, 254, ${a})`;
        this.starCtx.beginPath();
        this.starCtx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        this.starCtx.fill();
      }
    }

    renderAudioVisualizers() {
      if (!this.audio.ctx) return;

      if (this.scopeCtx && this.scopeCanvas) {
        const w = this.scopeCanvas.width;
        const h = this.scopeCanvas.height;
        this.audio.getTimeDomainData(this.timeData);

        this.scopeCtx.fillStyle = 'rgba(3, 11, 30, 0.4)';
        this.scopeCtx.fillRect(0, 0, w, h);

        this.scopeCtx.lineWidth = 2;
        this.scopeCtx.strokeStyle = '#00f0ff';
        this.scopeCtx.shadowColor = '#00f0ff';
        this.scopeCtx.shadowBlur = 6;
        this.scopeCtx.beginPath();

        const sliceWidth = w / this.timeData.length;
        let x = 0;
        for (let i = 0; i < this.timeData.length; i++) {
          const v = this.timeData[i] / 128.0;
          const y = (v * h) / 2;
          if (i === 0) this.scopeCtx.moveTo(x, y);
          else this.scopeCtx.lineTo(x, y);
          x += sliceWidth;
        }
        this.scopeCtx.stroke();
        this.scopeCtx.shadowBlur = 0;
      }

      if (this.spectrumCtx && this.spectrumCanvas) {
        const w = this.spectrumCanvas.width;
        const h = this.spectrumCanvas.height;
        this.audio.getFrequencyData(this.freqData);

        this.spectrumCtx.fillStyle = 'rgba(3, 11, 30, 0.4)';
        this.spectrumCtx.fillRect(0, 0, w, h);

        const barWidth = (w / this.freqData.length) * 0.9;
        let x = 0;

        for (let i = 0; i < this.freqData.length; i++) {
          const barHeight = (this.freqData[i] / 255) * h;
          const grad = this.spectrumCtx.createLinearGradient(0, h, 0, h - barHeight);
          grad.addColorStop(0, '#0284c7');
          grad.addColorStop(0.6, '#00f0ff');
          grad.addColorStop(1, '#f59e0b');

          this.spectrumCtx.fillStyle = grad;
          this.spectrumCtx.fillRect(x, h - barHeight, barWidth, barHeight);
          x += barWidth + 1.5;
        }
      }
    }

    updateHUDMetrics(metrics) {
      const longEl = document.getElementById('hud-longitude');
      const freqEl = document.getElementById('hud-freq');
      const colorSwatch = document.getElementById('hud-color-swatch');
      const densityMeter = document.getElementById('hud-density-fill');
      const noteEl = document.getElementById('hud-current-note');

      if (longEl) {
        const lon = ((metrics.xPosition * 360) - 180).toFixed(0);
        longEl.textContent = `${Math.abs(lon)}° ${lon >= 0 ? 'E' : 'W'}`;
      }
      if (freqEl) {
        const approxHz = Math.round(metrics.luminance * 1200 + 130);
        freqEl.textContent = `${approxHz} Hz`;
      }
      if (colorSwatch) {
        colorSwatch.style.backgroundColor = `hsl(${metrics.dominantHue}, ${Math.round(metrics.saturation * 100)}%, ${Math.round(metrics.lightness * 100)}%)`;
      }
      if (densityMeter) {
        densityMeter.style.width = `${Math.min(100, Math.round(metrics.density * 180))}%`;
      }
      if (noteEl) {
        const noteNames = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
        const noteIdx = Math.floor((metrics.dominantHue / 360) * 12) % 12;
        noteEl.textContent = noteNames[noteIdx];
      }
    }

    setupEventListeners() {
      const playBtn = document.getElementById('btn-play-sonification');
      if (playBtn) {
        playBtn.addEventListener('click', async () => {
          await this.audio.ensureRunning();
          this.isSonifying = !this.isSonifying;
          this.updatePlayButtonState();
          if (this.isSonifying) {
            this.a11y.announce(`Sonification active for ${this.currentDataset.title}`);
          }
        });
      }

      const animToggleBtn = document.getElementById('btn-toggle-animation');
      if (animToggleBtn) {
        animToggleBtn.addEventListener('click', () => this.toggleFrameAnimation());
      }

      const prevFrameBtn = document.getElementById('btn-prev-frame');
      if (prevFrameBtn) {
        prevFrameBtn.addEventListener('click', () => this.stepFrame(-1));
      }

      const nextFrameBtn = document.getElementById('btn-next-frame');
      if (nextFrameBtn) {
        nextFrameBtn.addEventListener('click', () => this.stepFrame(1));
      }

      const frameSlider = document.getElementById('frame-slider');
      if (frameSlider) {
        frameSlider.addEventListener('input', (e) => {
          this.currentFrameIndex = parseInt(e.target.value, 10);
          this.updateFrameDisplay();
        });
      }

      const synthSelect = document.getElementById('synth-select');
      if (synthSelect) {
        synthSelect.addEventListener('change', (e) => {
          this.audio.setSynth(e.target.value);
          this.a11y.announce(`Synthesizer changed to ${e.target.options[e.target.selectedIndex].text}`);
        });
      }

      const scaleSelect = document.getElementById('scale-select');
      if (scaleSelect) {
        scaleSelect.addEventListener('change', (e) => {
          this.audio.setScale(e.target.value);
          this.a11y.announce(`Harmonic scale set to ${e.target.options[e.target.selectedIndex].text}`);
        });
      }

      const volSlider = document.getElementById('volume-slider');
      if (volSlider) {
        volSlider.addEventListener('input', (e) => {
          this.audio.setVolume(parseFloat(e.target.value));
        });
      }

      const muteBtn = document.getElementById('btn-mute');
      if (muteBtn) {
        muteBtn.addEventListener('click', () => {
          const muted = this.audio.toggleMute();
          muteBtn.classList.toggle('muted', muted);
          muteBtn.setAttribute('aria-pressed', muted);
          muteBtn.title = muted ? 'Unmute Audio' : 'Mute Audio';
          this.a11y.announce(muted ? 'Audio muted' : 'Audio unmuted');
        });
      }

      const speedSelect = document.getElementById('scan-speed-select');
      if (speedSelect) {
        speedSelect.addEventListener('change', (e) => {
          this.scanSpeedMultiplier = parseFloat(e.target.value);
        });
      }

      if (this.mainCanvas) {
        const probeTooltip = document.getElementById('probe-tooltip');

        const handleProbe = async (clientX, clientY) => {
          const point = this.visual.analyzePoint(clientX, clientY);
          if (!point) return;

          await this.audio.ensureRunning();
          this.audio.playPointProbe(point.hue, point.sat, point.lightness, point.xNorm, point.yNorm);

          if (probeTooltip) {
            const rect = this.mainCanvas.getBoundingClientRect();
            probeTooltip.style.display = 'block';
            probeTooltip.style.left = `${clientX - rect.left + 15}px`;
            probeTooltip.style.top = `${clientY - rect.top + 15}px`;
            probeTooltip.innerHTML = `
              <div class="tooltip-title">${point.latitude}, ${point.longitude}</div>
              <div class="tooltip-row">
                <span class="swatch" style="background: rgb(${point.r}, ${point.g}, ${point.b})"></span>
                <span>RGB(${point.r}, ${point.g}, ${point.b})</span>
              </div>
              <div class="tooltip-row">Lum: ${Math.round(point.lum * 100)}% | Freq: ~${Math.round(point.lum * 1200 + 130)}Hz</div>
            `;
          }
        };

        this.mainCanvas.addEventListener('click', (e) => {
          handleProbe(e.clientX, e.clientY);
        });

        this.mainCanvas.addEventListener('mousemove', (e) => {
          if (e.buttons === 1) {
            handleProbe(e.clientX, e.clientY);
          }
        });

        this.mainCanvas.addEventListener('mouseleave', () => {
          if (probeTooltip) probeTooltip.style.display = 'none';
        });
      }

      const recordBtn = document.getElementById('btn-record-audio');
      if (recordBtn) {
        recordBtn.addEventListener('click', () => this.toggleRecording());
      }

      const uploadInput = document.getElementById('custom-image-input');
      const uploadBtn = document.getElementById('btn-upload-trigger');
      if (uploadBtn && uploadInput) {
        uploadBtn.addEventListener('click', () => uploadInput.click());
        uploadInput.addEventListener('change', (e) => this.handleCustomImageUpload(e));
      }

      const narrateBtn = document.getElementById('btn-audio-narration');
      if (narrateBtn) {
        narrateBtn.addEventListener('click', () => {
          const active = !this.a11y.isTTSActive;
          this.a11y.setTTS(active);
          narrateBtn.classList.toggle('active', active);
          narrateBtn.setAttribute('aria-pressed', active);
          if (active) {
            const text = `${this.currentDataset.title}. ${this.currentDataset.narrative(this.currentFrameIndex)}`;
            this.a11y.speak(text);
          } else {
            this.a11y.stopSpeaking();
          }
        });
      }

      const contrastBtn = document.getElementById('btn-high-contrast');
      if (contrastBtn) {
        contrastBtn.addEventListener('click', () => {
          const isHC = this.a11y.toggleHighContrast();
          contrastBtn.classList.toggle('active', isHC);
          contrastBtn.setAttribute('aria-pressed', isHC);
        });
      }

      window.addEventListener('keydown', (e) => this.handleKeyboardShortcut(e));

      const saveFavBtn = document.getElementById('btn-save-favorite');
      if (saveFavBtn) {
        saveFavBtn.addEventListener('click', () => {
          if (!this.auth.currentUser) {
            this.openModal('login-modal');
            this.showToast('Please log in or create an account to save favorite soundscapes!', 'info');
            return;
          }

          const favItem = {
            id: `fav-${Date.now()}`,
            datasetId: this.currentDataset.id,
            title: `${this.currentDataset.title} (${this.currentDataset.frameNames[this.currentFrameIndex] || 'Frame ' + (this.currentFrameIndex + 1)})`,
            synth: this.audio.currentSynth,
            scale: this.audio.currentScale,
            savedAt: new Date().toISOString()
          };

          this.auth.saveFavorite(favItem);
          this.showToast(`Saved "${favItem.title}" to your soundscapes!`, 'success');
        });
      }

      document.querySelectorAll('.modal-close, .modal-backdrop').forEach(el => {
        el.addEventListener('click', () => {
          const modal = el.closest('.modal');
          if (modal) modal.classList.remove('open');
        });
      });
    }

    setupAuthListeners() {
      const btnOpenLogin = document.getElementById('btn-open-login');
      const btnOpenSignup = document.getElementById('btn-open-signup');
      const btnUserProfile = document.getElementById('btn-user-profile');

      if (btnOpenLogin) btnOpenLogin.addEventListener('click', () => this.openModal('login-modal'));
      if (btnOpenSignup) btnOpenSignup.addEventListener('click', () => this.openModal('signup-modal'));
      if (btnUserProfile) btnUserProfile.addEventListener('click', () => this.openModal('profile-modal'));

      const linkToSignup = document.getElementById('link-to-signup');
      const linkToLogin = document.getElementById('link-to-login');
      if (linkToSignup) {
        linkToSignup.addEventListener('click', (e) => {
          e.preventDefault();
          this.closeModal('login-modal');
          this.openModal('signup-modal');
        });
      }
      if (linkToLogin) {
        linkToLogin.addEventListener('click', (e) => {
          e.preventDefault();
          this.closeModal('signup-modal');
          this.openModal('login-modal');
        });
      }

      const btnDemoLogin = document.getElementById('btn-demo-login');
      if (btnDemoLogin) {
        btnDemoLogin.addEventListener('click', () => {
          const res = this.auth.loginAsDemo();
          if (res.success) {
            this.closeModal('login-modal');
            this.showToast(`Welcome back, ${res.user.name}! (NASA Climate Sonification Fellow)`, 'success');
          }
        });
      }

      const loginForm = document.getElementById('login-form');
      if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
          e.preventDefault();
          const email = document.getElementById('login-email').value;
          const pass = document.getElementById('login-password').value;
          const errorEl = document.getElementById('login-error');

          const res = this.auth.login(email, pass);
          if (res.success) {
            errorEl.textContent = '';
            this.closeModal('login-modal');
            this.showToast(`Welcome back, ${res.user.name}!`, 'success');
          } else {
            errorEl.textContent = res.error;
          }
        });
      }

      const signupForm = document.getElementById('signup-form');
      if (signupForm) {
        signupForm.addEventListener('submit', (e) => {
          e.preventDefault();
          const name = document.getElementById('signup-name').value;
          const email = document.getElementById('signup-email').value;
          const password = document.getElementById('signup-password').value;
          const preferredSynth = document.getElementById('signup-synth').value;
          const preferredScale = document.getElementById('signup-scale').value;
          const screenReaderAnnounce = document.getElementById('signup-sr-toggle').checked;
          const highContrast = document.getElementById('signup-contrast-toggle').checked;
          const errorEl = document.getElementById('signup-error');

          const res = this.auth.signup({
            name,
            email,
            password,
            preferredSynth,
            preferredScale,
            accessibility: { screenReaderAnnounce, highContrast }
          });

          if (res.success) {
            errorEl.textContent = '';
            this.closeModal('signup-modal');
            this.showToast(`Account created! Welcome to Earth Jukebox, ${res.user.name}.`, 'success');
            this.audio.setSynth(preferredSynth);
            this.audio.setScale(preferredScale);
            if (highContrast) this.a11y.setHighContrast(true);
          } else {
            errorEl.textContent = res.error;
          }
        });
      }

      const btnLogout = document.getElementById('btn-logout');
      if (btnLogout) {
        btnLogout.addEventListener('click', () => {
          this.auth.logout();
          this.closeModal('profile-modal');
          this.showToast('You have been logged out.', 'info');
        });
      }

      this.auth.subscribe((user) => this.updateAuthUI(user));
      this.updateAuthUI(this.auth.currentUser);
    }

    updateAuthUI(user) {
      const unauthNav = document.getElementById('nav-unauthenticated');
      const authNav = document.getElementById('nav-authenticated');
      const userAvatar = document.getElementById('header-user-avatar');
      const userName = document.getElementById('header-user-name');

      if (user) {
        if (unauthNav) unauthNav.style.display = 'none';
        if (authNav) authNav.style.display = 'flex';
        if (userAvatar) userAvatar.textContent = user.avatar || user.name.slice(0, 2).toUpperCase();
        if (userName) userName.textContent = user.name;
        this.renderProfileModal(user);
      } else {
        if (unauthNav) unauthNav.style.display = 'flex';
        if (authNav) authNav.style.display = 'none';
      }
    }

    renderProfileModal(user) {
      if (!user) return;
      const profileName = document.getElementById('profile-name');
      const profileRole = document.getElementById('profile-role');
      const profileEmail = document.getElementById('profile-email');
      const favoritesList = document.getElementById('profile-favorites-list');

      if (profileName) profileName.textContent = user.name;
      if (profileRole) profileRole.textContent = user.role || 'Earth Science Explorer';
      if (profileEmail) profileEmail.textContent = user.email;

      if (favoritesList) {
        if (!user.savedSoundscapes || user.savedSoundscapes.length === 0) {
          favoritesList.innerHTML = `<div class="empty-state">No saved soundscapes yet. Explore a dataset and click "Save to Library"!</div>`;
        } else {
          favoritesList.innerHTML = user.savedSoundscapes.map(fav => `
            <div class="favorite-item">
              <div class="fav-info">
                <span class="fav-title">${fav.title}</span>
                <span class="fav-meta">Synth: ${fav.synth} | Scale: ${fav.scale}</span>
              </div>
              <div class="fav-actions">
                <button class="btn-fav-play" data-dataset="${fav.datasetId}" data-synth="${fav.synth}" data-scale="${fav.scale}" title="Play Soundscape">▶ Play</button>
                <button class="btn-fav-delete" data-id="${fav.id}" title="Remove">✕</button>
              </div>
            </div>
          `).join('');

          favoritesList.querySelectorAll('.btn-fav-play').forEach(btn => {
            btn.addEventListener('click', async () => {
              const dId = btn.getAttribute('data-dataset');
              const synth = btn.getAttribute('data-synth');
              const scale = btn.getAttribute('data-scale');
              this.loadDataset(dId);
              this.audio.setSynth(synth);
              this.audio.setScale(scale);
              document.getElementById('synth-select').value = synth;
              document.getElementById('scale-select').value = scale;
              this.closeModal('profile-modal');
              await this.audio.ensureRunning();
              this.isSonifying = true;
              this.updatePlayButtonState();
            });
          });

          favoritesList.querySelectorAll('.btn-fav-delete').forEach(btn => {
            btn.addEventListener('click', () => {
              const favId = btn.getAttribute('data-id');
              this.auth.removeFavorite(favId);
            });
          });
        }
      }
    }

    setupDatasetList() {
      const listEl = document.getElementById('dataset-list');
      if (!listEl) return;

      listEl.innerHTML = EIC_DATASETS.map((d, idx) => `
        <div class="dataset-card ${idx === 0 ? 'active' : ''}" data-id="${d.id}" role="button" tabindex="0" aria-label="${d.title}">
          <div class="card-header">
            <span class="dataset-num">0${idx + 1}</span>
            <span class="dataset-time">${d.timeRange}</span>
          </div>
          <div class="dataset-card-title">${d.title}</div>
          <div class="dataset-card-sub">${d.subtitle}</div>
          <div class="dataset-tags">
            <span class="tag-mission">${d.mission}</span>
            <span class="tag-synth">${d.audioProfile.defaultSynth}</span>
          </div>
        </div>
      `).join('');

      listEl.querySelectorAll('.dataset-card').forEach(card => {
        card.addEventListener('click', () => {
          const id = card.getAttribute('data-id');
          this.loadDataset(id);
        });
        card.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.loadDataset(card.getAttribute('data-id'));
          }
        });
      });
    }

    loadDataset(datasetId) {
      const dataset = EIC_DATASETS.find(d => d.id === datasetId) || EIC_DATASETS[0];
      this.currentDataset = dataset;
      this.currentFrameIndex = 0;
      this.visual.clearCustomImage();

      document.querySelectorAll('.dataset-card').forEach(card => {
        card.classList.toggle('active', card.getAttribute('data-id') === dataset.id);
      });

      this.audio.setSynth(dataset.audioProfile.defaultSynth);
      this.audio.setScale(dataset.audioProfile.recommendedScale);
      const synthSelect = document.getElementById('synth-select');
      const scaleSelect = document.getElementById('scale-select');
      if (synthSelect) synthSelect.value = dataset.audioProfile.defaultSynth;
      if (scaleSelect) scaleSelect.value = dataset.audioProfile.recommendedScale;

      const titleEl = document.getElementById('active-dataset-title');
      const subEl = document.getElementById('active-dataset-sub');
      const missionEl = document.getElementById('active-mission-info');
      const scientificInsightsEl = document.getElementById('dataset-insights');
      const colorLegendEl = document.getElementById('color-legend-bar');

      if (titleEl) titleEl.textContent = dataset.title;
      if (subEl) subEl.textContent = dataset.subtitle;
      if (missionEl) missionEl.textContent = `Mission: ${dataset.mission} | Instrument: ${dataset.instrument}`;

      if (scientificInsightsEl) {
        scientificInsightsEl.innerHTML = dataset.scientificInsights.map(fact => `
          <li class="insight-item"><span class="insight-bullet">✦</span> ${fact}</li>
        `).join('');
      }

      if (colorLegendEl) {
        colorLegendEl.innerHTML = `
          <div class="legend-header"><span>${dataset.units}</span></div>
          <div class="legend-gradient" style="background: linear-gradient(to right, ${dataset.colorLegend.map(c => c.color).join(', ')})"></div>
          <div class="legend-labels">
            ${dataset.colorLegend.map(c => `<span>${c.label}</span>`).join('')}
          </div>
        `;
      }

      const frameSlider = document.getElementById('frame-slider');
      if (frameSlider) {
        frameSlider.min = 0;
        frameSlider.max = dataset.totalFrames - 1;
        frameSlider.value = 0;
      }

      this.updateFrameDisplay();
      this.a11y.announce(`Loaded ${dataset.title}. Suggested synth: ${dataset.audioProfile.defaultSynth}. Suggested scale: ${dataset.audioProfile.recommendedScale}.`);
      this.auth.addHistory(`Explored ${dataset.title}`);
    }

    updateFrameDisplay() {
      const frameLabel = document.getElementById('current-frame-label');
      const frameCount = document.getElementById('frame-counter');
      const narrativeEl = document.getElementById('frame-narrative-text');

      const total = this.currentDataset.totalFrames || 1;
      const name = this.currentDataset.frameNames[this.currentFrameIndex] || `Frame ${this.currentFrameIndex + 1}`;

      if (frameLabel) frameLabel.textContent = name;
      if (frameCount) frameCount.textContent = `${this.currentFrameIndex + 1} / ${total}`;

      const text = this.currentDataset.narrative(this.currentFrameIndex);
      if (narrativeEl) narrativeEl.textContent = text;

      if (this.a11y.isTTSActive) {
        this.a11y.speak(text, true);
      }
    }

    stepFrame(delta) {
      const total = this.currentDataset.totalFrames || 1;
      this.currentFrameIndex = (this.currentFrameIndex + delta + total) % total;
      const slider = document.getElementById('frame-slider');
      if (slider) slider.value = this.currentFrameIndex;
      this.updateFrameDisplay();
    }

    toggleFrameAnimation() {
      this.isPlayingFrames = !this.isPlayingFrames;
      const btn = document.getElementById('btn-toggle-animation');
      if (btn) {
        btn.innerHTML = this.isPlayingFrames ? '⏸ Pause Time-Lapse' : '▶ Play Time-Lapse';
        btn.classList.toggle('playing', this.isPlayingFrames);
      }

      if (this.isPlayingFrames) {
        this.frameTimer = setInterval(() => {
          this.stepFrame(1);
        }, this.frameSpeedMs);
      } else {
        if (this.frameTimer) clearInterval(this.frameTimer);
      }
    }

    updatePlayButtonState() {
      const btn = document.getElementById('btn-play-sonification');
      const playIndicator = document.getElementById('play-indicator');
      if (btn) {
        btn.classList.toggle('active', this.isSonifying);
        btn.innerHTML = this.isSonifying
          ? '<span class="icon-pulse"></span> Stop Sonification'
          : '<span class="icon-play">▶</span> Start Sonification';
      }
      if (playIndicator) {
        playIndicator.textContent = this.isSonifying ? 'LIVE SONIFICATION' : 'AUDIO PAUSED';
        playIndicator.className = this.isSonifying ? 'status-pill live' : 'status-pill paused';
      }
    }

    handleCustomImageUpload(e) {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          this.visual.setCustomImage(img);
          this.showToast(`Custom satellite image "${file.name}" loaded for sonification!`, 'success');
          this.a11y.announce(`Loaded custom image ${file.name}. Computer vision sonification ready.`);
        };
        img.src = event.target.result;
      };
      reader.readAsDataURL(file);
    }

    async toggleRecording() {
      const recordBtn = document.getElementById('btn-record-audio');
      const recordTimer = document.getElementById('record-timer');

      if (!this.audio.isRecording) {
        await this.audio.ensureRunning();
        const started = this.audio.startRecording();
        if (!started) {
          this.showToast('Unable to start recording. Please ensure audio is playing.', 'error');
          return;
        }

        this.recordingSeconds = 0;
        if (recordBtn) {
          recordBtn.classList.add('recording');
          recordBtn.innerHTML = '<span class="rec-dot"></span> Stop & Save Recording';
        }

        this.recordingInterval = setInterval(() => {
          this.recordingSeconds++;
          const mins = String(Math.floor(this.recordingSeconds / 60)).padStart(2, '0');
          const secs = String(this.recordingSeconds % 60).padStart(2, '0');
          if (recordTimer) recordTimer.textContent = `${mins}:${secs}`;
        }, 1000);

        this.showToast('Live sonification recording started!', 'info');
      } else {
        clearInterval(this.recordingInterval);
        const res = await this.audio.stopRecording();

        if (recordBtn) {
          recordBtn.classList.remove('recording');
          recordBtn.innerHTML = '<span class="rec-dot"></span> Record Sonification';
        }
        if (recordTimer) recordTimer.textContent = '00:00';

        if (res && res.url) {
          const a = document.createElement('a');
          a.href = res.url;
          a.download = `NASA-Earth-Jukebox-${this.currentDataset.id}-${Date.now()}.webm`;
          a.click();
          this.showToast('Recording complete! File downloaded.', 'success');
          this.auth.addHistory(`Recorded sonification for ${this.currentDataset.title}`);
        }
      }
    }

    handleKeyboardShortcut(e) {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) return;

      switch (e.key) {
        case ' ':
          e.preventDefault();
          document.getElementById('btn-play-sonification').click();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          this.stepFrame(-1);
          break;
        case 'ArrowRight':
          e.preventDefault();
          this.stepFrame(1);
          break;
        case 'm':
        case 'M':
          document.getElementById('btn-mute').click();
          break;
        case 'r':
        case 'R':
          this.toggleRecording();
          break;
        case '?':
        case 'h':
        case 'H':
          this.openModal('help-modal');
          break;
      }
    }

    openModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) {
        modal.classList.add('open');
        const firstInput = modal.querySelector('input, button');
        if (firstInput) firstInput.focus();
      }
    }

    closeModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) modal.classList.remove('open');
    }

    showToast(message, type = 'info') {
      const container = document.getElementById('toast-container');
      if (!container) return;

      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.innerHTML = `
        <span class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '⚠' : 'ℹ'}</span>
        <span class="toast-message">${message}</span>
      `;

      container.appendChild(toast);
      setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 400);
      }, 4000);
    }
  }

  // Initialize on DOM load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      window.earthApp = new EarthJukeboxApp();
    });
  } else {
    window.earthApp = new EarthJukeboxApp();
  }

})();
