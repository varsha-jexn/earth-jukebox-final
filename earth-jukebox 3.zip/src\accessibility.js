/**
 * NASA Earth Jukebox - Accessibility & Multi-Sensory Services
 * Supports blind & low-vision users through screen-reader announcements, TTS speech narratives,
 * high-contrast theming, keyboard controls, and haptic feedback.
 */

export class AccessibilityService {
  constructor() {
    this.speechSynth = window.speechSynthesis || null;
    this.isTTSActive = false;
    this.isHighContrast = false;
    this.announcerElement = null;
    this.initAnnouncer();
  }

  initAnnouncer() {
    let el = document.getElementById('sr-announcements');
    if (!el) {
      el = document.createElement('div');
      el.id = 'sr-announcements';
      el.setAttribute('aria-live', 'polite');
      el.setAttribute('aria-atomic', 'true');
      el.className = 'sr-only';
      document.body.appendChild(el);
    }
    this.announcerElement = el;
  }

  /**
   * Announce message to Screen Readers via ARIA-live
   */
  announce(message, priority = 'polite') {
    if (!this.announcerElement) return;
    this.announcerElement.setAttribute('aria-live', priority);
    this.announcerElement.textContent = '';
    // Small timeout ensures screen readers catch the text mutation
    setTimeout(() => {
      this.announcerElement.textContent = message;
    }, 50);
  }

  /**
   * Speak narrative using Web Speech API (Text-to-Speech)
   */
  speak(text, interrupt = false) {
    if (!this.speechSynth || !this.isTTSActive) return;

    if (interrupt) {
      this.speechSynth.cancel();
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;
    utterance.volume = 0.9;

    // Try to pick a natural English voice
    const voices = this.speechSynth.getVoices();
    const preferredVoice = voices.find(v => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Siri')));
    if (preferredVoice) utterance.voice = preferredVoice;

    this.speechSynth.speak(utterance);
  }

  stopSpeaking() {
    if (this.speechSynth) {
      this.speechSynth.cancel();
    }
  }

  setTTS(active) {
    this.isTTSActive = active;
    if (!active) this.stopSpeaking();
  }

  /**
   * Toggle High Contrast Theme
   */
  toggleHighContrast() {
    this.isHighContrast = !this.isHighContrast;
    document.body.classList.toggle('high-contrast-mode', this.isHighContrast);
    this.announce(`High contrast mode ${this.isHighContrast ? 'activated' : 'deactivated'}`);
    return this.isHighContrast;
  }

  setHighContrast(enabled) {
    this.isHighContrast = enabled;
    document.body.classList.toggle('high-contrast-mode', this.isHighContrast);
  }

  /**
   * Provide tactile haptic feedback (if hardware supports)
   */
  vibrate(pattern = [25]) {
    if ('vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch (e) {
        // Ignored if browser blocks vibration without direct touch
      }
    }
  }

  /**
   * Generate natural language description of current frame & sonification metrics
   */
  formatMetricsNarrative(dataset, frameIndex, metrics) {
    if (!dataset || !metrics) return '';

    const longitude = ((metrics.xPosition * 360) - 180).toFixed(0);
    const longDir = longitude >= 0 ? 'East' : 'West';
    const absLong = Math.abs(longitude);

    let spectralColor = 'neutral';
    if (metrics.dominantHue >= 340 || metrics.dominantHue < 25) spectralColor = 'warm red, indicating high thermal or emission concentration';
    else if (metrics.dominantHue >= 25 && metrics.dominantHue < 60) spectralColor = 'amber and yellow, indicating moderate intensity or vegetation stress';
    else if (metrics.dominantHue >= 60 && metrics.dominantHue < 170) spectralColor = 'green, indicating active vegetative chlorophyll and carbon sinks';
    else if (metrics.dominantHue >= 170 && metrics.dominantHue < 260) spectralColor = 'cyan and deep oceanic blue, indicating cool waters and atmospheric stability';
    else spectralColor = 'violet and magenta, indicating extreme polar vortex or low anomaly regions';

    const densityLevel = metrics.density > 0.4 ? 'high density' : metrics.density > 0.15 ? 'moderate density' : 'sparse density';

    return `Scan meridian at ${absLong} degrees ${longDir}. Visual palette is ${spectralColor} with ${densityLevel}. Audio synthesis frequency centered around ${Math.round(metrics.luminance * 1000 + 130)} Hertz.`;
  }
}
