/**
 * NASA Earth Information Center (EIC) - Scientific Datasets & Visual Frame Generators
 * Provides authentic planetary datasets, time-series frame generators, and sonification mappings.
 */

export const EIC_DATASETS = [
  {
    id: 'sst-anomaly',
    title: 'Global Sea Surface Temperature & Ocean Currents',
    subtitle: 'Thermal anomalies tracking El Niño, La Niña, and oceanic heatwaves',
    mission: 'NASA Terra & Aqua / Copernicus Sentinel-3',
    instrument: 'MODIS & SLSTR Infrared Radiometers',
    timeRange: '12-Month Seasonal & Multi-Year Cycle',
    units: '°C Anomaly (-4°C to +4°C)',
    colorLegend: [
      { color: '#1d4ed8', label: '-4°C' },
      { color: '#06b6d4', label: '-2°C' },
      { color: '#10b981', label: '0°C (Normal)' },
      { color: '#f59e0b', label: '+2°C' },
      { color: '#ef4444', label: '+4°C (Severe Heatwave)' }
    ],
    scientificInsights: [
      'Oceans absorb over 90% of excess heat trapped by greenhouse gases.',
      'Marine heatwaves devastate coral reef ecosystems and trigger intense hurricane activity.',
      'The equatorial Pacific "warm tongue" oscillation alters global weather patterns and atmospheric circulation.'
    ],
    audioProfile: {
      defaultSynth: 'ocean-drone',
      recommendedScale: 'lydian',
      baseNote: 'C3',
      scanRate: 1.0,
      description: 'Deep resonant sub-frequencies for cold polar abysses; warm harmonic swells for equatorial current tongues; shimmering high pitches for marine heatwave pulses.'
    },
    totalFrames: 12,
    frameNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    narrative: (frameIndex) => {
      const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      const month = months[frameIndex % 12];
      return `Frame ${frameIndex + 1} (${month}): Oceanic thermal scan shows intensified equatorial Pacific warming with energetic heat exchange off the Gulf Stream and Kuroshio current.`;
    }
  },
  {
    id: 'atmospheric-co2',
    title: 'Atmospheric Carbon Dioxide & Emission Plumes',
    subtitle: 'Global CO2 concentrations from industrial emissions and plant respiration',
    mission: 'Orbiting Carbon Observatory-2 (OCO-2) & GEOS Model',
    instrument: 'Three-Band High-Resolution Spectrometer',
    timeRange: 'Annual Biosphere Respiration Cycle',
    units: 'ppm (390 to 425 ppm)',
    colorLegend: [
      { color: '#047857', label: '390 ppm (Active Sinks)' },
      { color: '#eab308', label: '405 ppm (Mid-Latitude Baseline)' },
      { color: '#ea580c', label: '415 ppm (Urban/Industrial Plume)' },
      { color: '#dc2626', label: '425+ ppm (Peak Concentration)' }
    ],
    scientificInsights: [
      'Atmospheric CO2 has surged past 420 ppm—the highest concentration in over 3 million years.',
      'The Northern Hemisphere "breathes" each year: forests draw down CO2 in summer and release it in winter.',
      'Industrial corridors over North America, Europe, and East Asia manifest as concentrated reddish acoustic plumes.'
    ],
    audioProfile: {
      defaultSynth: 'cyber-pulse',
      recommendedScale: 'chromatic-tension',
      baseNote: 'D3',
      scanRate: 1.2,
      description: 'Fast, rhythmic staccato pulses for dense industrial emissions; soaring tense chords reflect surging carbon concentrations across industrialized continents.'
    },
    totalFrames: 12,
    frameNames: ['Jan Peak Winter Plumes', 'Feb High Respiration', 'Mar Arctic Trap', 'Apr Spring Turn', 'May Forest Awakening', 'Jun Rapid Sinks', 'Jul Summer Minimum', 'Aug Northern Drawdown', 'Sep Fall Rebound', 'Oct Deciduous Drop', 'Nov Heating Cycle', 'Dec Winter Buildup'],
    narrative: (frameIndex) => {
      const phases = [
        'Winter stagnation: intense red CO2 accumulation across North American and Eurasian industrial hubs.',
        'Late winter: carbon concentrations pool in the Arctic basin.',
        'Early spring: northern boreal forests begin waking up from dormancy.',
        'Spring equinox: atmospheric CO2 begins noticeable seasonal inflection.',
        'Late spring: burgeoning photosynthesis begins absorbing gigatons of carbon.',
        'Early summer: strong green sink zones emerge across the boreal forest and Amazon.',
        'Mid-summer: global atmospheric CO2 dips to its annual minimum as plants breathe in.',
        'Late summer: peak photosynthetic drawdown across temperate deciduous forests.',
        'Early autumn: harvest and leaf senescence slow down carbon absorption.',
        'Autumn: microbial decomposition begins releasing stored carbon back to the air.',
        'Late autumn: heating and industrial combustion emissions ramp up across northern latitudes.',
        'Early winter: dense emission plumes reform over high-density population centers.'
      ];
      return phases[frameIndex % 12];
    }
  },
  {
    id: 'sea-ice-extent',
    title: 'Arctic & Antarctic Polar Sea Ice Extent',
    subtitle: 'Decadal satellite monitoring of Earth\'s shrinking polar cryosphere',
    mission: 'Nimbus-7, DMSP, AMSR-E, ICESat-2',
    instrument: 'Special Sensor Microwave Imager (SSM/I) & ATLAS Laser',
    timeRange: '1980 to 2024 Long-Term Cryosphere Trend',
    units: 'Million km² Ice Cover (3.5 to 16.5 M km²)',
    colorLegend: [
      { color: '#0f172a', label: 'Open Ocean (Deep Water)' },
      { color: '#0284c7', label: 'Marginal Ice Zone' },
      { color: '#38bdf8', label: 'First-Year Sea Ice' },
      { color: '#f8fafc', label: 'Perennial Multi-Year Pack Ice' }
    ],
    scientificInsights: [
      'Arctic sea ice is declining at a rate of 12.6% per decade relative to the 1981-2010 average.',
      'Loss of reflective white ice triggers the "ice-albedo feedback", causing polar waters to absorb more solar heat.',
      'Older, thicker multi-year ice has virtually disappeared, replaced by fragile seasonal first-year ice.'
    ],
    audioProfile: {
      defaultSynth: 'chime-marimba',
      recommendedScale: 'dorian',
      baseNote: 'E3',
      scanRate: 0.8,
      description: 'Crystalline, glassy bell strikes and high marimba harmonics for thick ice shelves, transitioning to muted, hollow low-frequency oceanic murmurs as ice retreats.'
    },
    totalFrames: 10,
    frameNames: ['1980 Baseline', '1985 Decade Start', '1990 Steady Extent', '1995 Initial Thinning', '2000 Accelerating Loss', '2005 Historic Minimums', '2012 Record Low', '2016 Winter Anomaly', '2020 Fragile Cover', '2024 Modern Cryosphere'],
    narrative: (frameIndex) => {
      const stages = [
        '1980: Robust multi-year Arctic pack ice spans over 7.8 million square kilometers in September.',
        '1985: Stable winter ice shelf with high acoustic density across the Beaufort Gyre.',
        '1990: Minor cyclical retreat with persistent thick ice hugging northern Greenland.',
        '1995: Measurable thinning begins in peripheral seas (Barents and Kara seas).',
        '2000: Multi-year ice thickness drops by over 30%, increasing acoustic volatility.',
        '2005: Significant summer melt window opens the Northern Sea Route.',
        '2012: Historic all-time record minimum Arctic ice extent of 3.41 million square kilometers.',
        '2016: Unprecedented winter heatwaves impede freeze-up, weakening harmonic resonance.',
        '2020: Second-lowest ice extent on record; extensive dark open water absorption.',
        '2024: Fragile young seasonal ice dominates; polar cryosphere sonification sounds hollow and sparse.'
      ];
      return stages[frameIndex % 10];
    }
  },
  {
    id: 'biosphere-ndvi',
    title: 'Global Biosphere & Normalized Difference Vegetation Index (NDVI)',
    subtitle: 'The living "pulse" of Earth\'s plant life and seasonal greening',
    mission: 'Terra & Aqua / Suomi NPP',
    instrument: 'MODIS & VIIRS Visible/Infrared Spectroradiometer',
    timeRange: '12-Month Continental Biosphere Pulse',
    units: 'NDVI Index (0.0 Desert / Water to 0.9 Lush Canopy)',
    colorLegend: [
      { color: '#d97706', label: '0.1 Arid / Desert' },
      { color: '#ca8a04', label: '0.3 Scrubland / Tundra' },
      { color: '#84cc16', label: '0.5 Grassland / Savanna' },
      { color: '#15803d', label: '0.7 Temperate Forest' },
      { color: '#052e16', label: '0.9 Dense Equatorial Rainforest' }
    ],
    scientificInsights: [
      'The biosphere acts as Earth\'s lungs, absorbing approximately 30% of anthropogenic carbon emissions.',
      'Seasonal green waves sweep northward from the equator into the Canadian and Siberian taiga every spring.',
      'Droughts, deforestation, and changing monsoon cycles noticeably alter vegetation acoustic rhythms.'
    ],
    audioProfile: {
      defaultSynth: 'cosmic-ambient',
      recommendedScale: 'pentatonic-major',
      baseNote: 'F3',
      scanRate: 0.9,
      description: 'Organic woodwind swells and vibrant pentatonic flutes; lush rainforests generate rich multi-tone chords, while arid deserts resonate in quiet, dry open intervals.'
    },
    totalFrames: 12,
    frameNames: ['Jan Winter Slumber', 'Feb Equatorial Green', 'Mar Vernal Awakening', 'Apr Temperate Budding', 'May Boreal Surge', 'Jun Peak Taiga Vitality', 'Jul Global Maximum', 'Aug Late Summer Canopy', 'Sep Autumn Transmutation', 'Oct Fall Foliage Descent', 'Nov Boreal Dormancy', 'Dec Solstice Calm'],
    narrative: (frameIndex) => {
      const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      return `${months[frameIndex % 12]}: Continental plant biomass sweeps rhythmically; tropical rain belts over the Congo and Amazon emit strong melodic harmony.`;
    }
  },
  {
    id: 'earth-at-night',
    title: 'Earth at Night: Global Energy & Luminescence',
    subtitle: 'Human civilization footprint, electrical grids, and urban settlement',
    mission: 'Suomi NPP & NOAA-20',
    instrument: 'VIIRS Day/Night Band (DNB) Low-Light Sensor',
    timeRange: 'Global Nocturnal Energy Mapping',
    units: 'Radiance (nW/cm²/sr)',
    colorLegend: [
      { color: '#030712', label: 'Unlit Oceans & Remote Wilderness' },
      { color: '#1e3a8a', label: 'Offshore Energy & Fishing Fleets' },
      { color: '#f59e0b', label: 'Suburban Arteries & Towns' },
      { color: '#fef08a', label: 'Megacities & Dense Urban Centers' },
      { color: '#ffffff', label: 'Peak Luminescence (Metropolitan Cores)' }
    ],
    scientificInsights: [
      'Light pollution has increased by nearly 10% each year, impacting nocturnal ecosystems and stargazing.',
      'Satellite night imagery accurately tracks socioeconomic development, disaster power outages, and conflict zones.',
      'Stark acoustic contrasts separate glowing continental corridors from vast dark ocean and forest expanses.'
    ],
    audioProfile: {
      defaultSynth: 'cyber-pulse',
      recommendedScale: 'pentatonic-minor',
      baseNote: 'A2',
      scanRate: 1.1,
      description: 'Deep nocturnal silence punctuated by sparkling, electric arpeggios that burst with rapid percussive notes whenever the scanline strikes illuminated metropolitan clusters.'
    },
    totalFrames: 6,
    frameNames: ['Global Luminescence Map', 'Western Megalopolis Focus', 'European Interconnected Grid', 'East Asian Night Lights', 'Nile Delta & Middle East', 'Trans-Oceanic Shipping & Offshore Platforms'],
    narrative: (frameIndex) => {
      const views = [
        'Full planetary night scan: shimmering electrical networks trace continental coastlines and major transport arteries.',
        'North American grid: intense sonic cluster across the Boston-Washington megalopolis and Great Lakes.',
        'European constellation: continuous web of illuminated cities radiating from London, Paris, and the Rhine Valley.',
        'East Asian brilliance: hyper-dense acoustic spark showers over the Pearl River Delta, Tokyo, and Seoul.',
        'Nile river ribbon: brilliant linear streak of light cutting through the silent Egyptian desert.',
        'Offshore signatures: pinpoint harmonic bursts from oil platforms, gas flares, and squid fishing fleets.'
      ];
      return views[frameIndex % 6];
    }
  },
  {
    id: 'ozone-hole',
    title: 'Antarctic Ozone Layer & Stratospheric Recovery',
    subtitle: 'Tracking Montreal Protocol atmospheric healing and polar vortex chemistry',
    mission: 'Aura, Suomi NPP & Sentinel-5P',
    instrument: 'OMI & TROPOMI UV Spectrometer',
    timeRange: 'Springtime Polar Vortex Dynamics',
    units: 'Dobson Units (100 to 450 DU)',
    colorLegend: [
      { color: '#4c1d95', label: '< 150 DU (Severe Ozone Hole)' },
      { color: '#2563eb', label: '200 DU (Depletion Threshold)' },
      { color: '#06b6d4', label: '275 DU (Mid-Latitude Average)' },
      { color: '#eab308', label: '350 DU (Rich Stratosphere)' },
      { color: '#ef4444', label: '> 400 DU (Maximum Concentration Ring)' }
    ],
    scientificInsights: [
      'The 1987 Montreal Protocol banned chlorofluorocarbons (CFCs), preventing catastrophic UV exposure.',
      'The ozone hole forms each austral spring (September-October) as sunlight activates reactive chlorine in polar stratospheric clouds.',
      'The ozone layer is projected to recover to 1980 levels over Antarctica by approximately 2066.'
    ],
    audioProfile: {
      defaultSynth: 'solar-shimmer',
      recommendedScale: 'lydian',
      baseNote: 'G3',
      scanRate: 0.9,
      description: 'Eerie, suspended high-pass frequency hollows representing the depleted polar hole; surrounded by rich, triumphant harmonic fanfares of ozone-rich collar rings.'
    },
    totalFrames: 8,
    frameNames: ['August Vortex Formation', 'Early September Depletion', 'Late September Minimum', 'Peak October Hole', 'Late October Stretching', 'November Breakdown', 'December Healing', 'Summer Recovery Baseline'],
    narrative: (frameIndex) => {
      const phases = [
        'Austral winter cold stabilizes the polar stratospheric vortex; ozone hole begins forming.',
        'September dawn: solar UV rays trigger chlorine catalysts, carving a steep acoustic vacuum.',
        'Late September: ozone values plummet below 130 Dobson Units over the South Pole.',
        'October maximum extent: the ozone depletion area expands to encompass all of Antarctica.',
        'Late October: planetary atmospheric waves begin distorting and elongating the vortex.',
        'November warming: polar stratospheric clouds dissolve, shutting down catalytic destruction.',
        'Early December: ozone-rich sub-polar air masses surge inward, filling the acoustic hollow.',
        'Summer solstice: normal atmospheric equilibrium restored across the high southern latitudes.'
      ];
      return phases[frameIndex % 8];
    }
  }
];

/**
 * Procedural Realistic Satellite Canvas Renderer for EIC Visual Frames
 * Renders scientific data maps for each dataset across time-series frames with true geographic contours.
 */
export function renderEICFrame(ctx, width, height, datasetId, frameIndex, scanPosition = null) {
  // Clear canvas
  ctx.fillStyle = '#030816';
  ctx.fillRect(0, 0, width, height);

  const dataset = EIC_DATASETS.find(d => d.id === datasetId) || EIC_DATASETS[0];
  const t = (frameIndex / (dataset.totalFrames || 1)) * Math.PI * 2;

  // Draw procedural Earth map with scientific data layers
  drawEarthBackground(ctx, width, height);

  switch (datasetId) {
    case 'sst-anomaly':
      drawSSTLayer(ctx, width, height, t, frameIndex);
      break;
    case 'atmospheric-co2':
      drawCO2Layer(ctx, width, height, t, frameIndex);
      break;
    case 'sea-ice-extent':
      drawSeaIceLayer(ctx, width, height, frameIndex, dataset.totalFrames);
      break;
    case 'biosphere-ndvi':
      drawNDVILayer(ctx, width, height, t, frameIndex);
      break;
    case 'earth-at-night':
      drawNightLightsLayer(ctx, width, height, frameIndex);
      break;
    case 'ozone-hole':
      drawOzoneLayer(ctx, width, height, t, frameIndex);
      break;
    default:
      drawSSTLayer(ctx, width, height, t, frameIndex);
  }

  // Draw latitude/longitude grid overlay for NASA scientific feel
  drawScientificGrid(ctx, width, height);

  // Draw scan beam if active
  if (scanPosition !== null && scanPosition >= 0 && scanPosition <= 1) {
    drawScanBeam(ctx, width, height, scanPosition);
  }
}

/**
 * Basic Continental Outlines / Landmasses (Equirectangular Projection)
 */
function drawEarthBackground(ctx, w, h) {
  // Deep oceanic blue
  ctx.fillStyle = '#061633';
  ctx.fillRect(0, 0, w, h);

  // Draw landmass silhouettes with soft texture
  ctx.fillStyle = '#0f2942';
  drawContinents(ctx, w, h);
}

function drawContinents(ctx, w, h) {
  ctx.save();
  ctx.beginPath();

  // North America
  ctx.moveTo(w * 0.12, h * 0.25);
  ctx.bezierCurveTo(w * 0.15, h * 0.18, w * 0.25, h * 0.15, w * 0.32, h * 0.22);
  ctx.bezierCurveTo(w * 0.28, h * 0.35, w * 0.24, h * 0.42, w * 0.22, h * 0.52); // Florida / Gulf
  ctx.bezierCurveTo(w * 0.18, h * 0.55, w * 0.14, h * 0.45, w * 0.10, h * 0.38); // West Coast
  ctx.closePath();
  ctx.fill();

  // South America
  ctx.beginPath();
  ctx.moveTo(w * 0.25, h * 0.52);
  ctx.bezierCurveTo(w * 0.35, h * 0.56, w * 0.38, h * 0.65, w * 0.32, h * 0.82); // Brazil to Argentina
  ctx.bezierCurveTo(w * 0.28, h * 0.90, w * 0.26, h * 0.80, w * 0.25, h * 0.68); // Chile / Andes
  ctx.closePath();
  ctx.fill();

  // Eurasia & Africa
  ctx.beginPath();
  // Europe & Asia
  ctx.moveTo(w * 0.45, h * 0.22);
  ctx.bezierCurveTo(w * 0.52, h * 0.16, w * 0.70, h * 0.14, w * 0.85, h * 0.24); // Siberia / East Asia
  ctx.bezierCurveTo(w * 0.88, h * 0.38, w * 0.80, h * 0.48, w * 0.70, h * 0.46); // China / India
  ctx.bezierCurveTo(w * 0.62, h * 0.44, w * 0.56, h * 0.38, w * 0.50, h * 0.35); // Middle East
  ctx.closePath();
  ctx.fill();

  // Africa
  ctx.beginPath();
  ctx.moveTo(w * 0.47, h * 0.38);
  ctx.bezierCurveTo(w * 0.58, h * 0.40, w * 0.60, h * 0.55, w * 0.55, h * 0.75); // East & South Africa
  ctx.bezierCurveTo(w * 0.48, h * 0.80, w * 0.44, h * 0.60, w * 0.42, h * 0.48); // West Africa
  ctx.closePath();
  ctx.fill();

  // Australia
  ctx.beginPath();
  ctx.ellipse(w * 0.82, h * 0.72, w * 0.07, h * 0.08, 0.2, 0, Math.PI * 2);
  ctx.fill();

  // Antarctica
  ctx.beginPath();
  ctx.rect(0, h * 0.90, w, h * 0.10);
  ctx.fill();

  // Greenland
  ctx.beginPath();
  ctx.ellipse(w * 0.36, h * 0.16, w * 0.04, h * 0.06, 0.2, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

/**
 * 1. Sea Surface Temperature Anomaly
 */
function drawSSTLayer(ctx, w, h, t, frameIndex) {
  ctx.save();
  ctx.globalCompositeOperation = 'screen';

  // Base oceanic thermal gradient (cold poles, warm tropics)
  const oceanGrad = ctx.createLinearGradient(0, 0, 0, h);
  oceanGrad.addColorStop(0, 'rgba(30, 58, 138, 0.8)');   // North Arctic cold
  oceanGrad.addColorStop(0.3, 'rgba(6, 182, 212, 0.5)'); // North temperate
  oceanGrad.addColorStop(0.5, 'rgba(239, 68, 68, 0.7)');  // Equator warm
  oceanGrad.addColorStop(0.7, 'rgba(6, 182, 212, 0.5)'); // South temperate
  oceanGrad.addColorStop(1, 'rgba(30, 58, 138, 0.8)');   // Antarctic cold
  ctx.fillStyle = oceanGrad;
  ctx.fillRect(0, 0, w, h);

  // El Niño / La Niña Equatorial Pacific warm tongue
  const elNinoPhase = Math.sin(t + 0.5) * 0.5 + 0.5; // 0 to 1
  const tongueX = w * 0.15;
  const tongueY = h * 0.52;
  const tongueW = w * 0.35 + elNinoPhase * (w * 0.1);
  const tongueH = h * 0.08;

  const tongueGrad = ctx.createRadialGradient(
    tongueX + tongueW * 0.6, tongueY, 5,
    tongueX + tongueW * 0.5, tongueY, tongueW * 0.5
  );
  tongueGrad.addColorStop(0, `rgba(239, 68, 68, ${0.7 + elNinoPhase * 0.3})`);
  tongueGrad.addColorStop(0.5, `rgba(245, 158, 11, ${0.6 + elNinoPhase * 0.2})`);
  tongueGrad.addColorStop(1, 'rgba(245, 158, 11, 0)');

  ctx.fillStyle = tongueGrad;
  ctx.beginPath();
  ctx.ellipse(tongueX + tongueW * 0.5, tongueY, tongueW * 0.5, tongueH, 0, 0, Math.PI * 2);
  ctx.fill();

  // Gulf Stream heat current
  const gulfGrad = ctx.createRadialGradient(w * 0.30, h * 0.35, 10, w * 0.34, h * 0.32, w * 0.15);
  gulfGrad.addColorStop(0, 'rgba(239, 68, 68, 0.7)');
  gulfGrad.addColorStop(0.6, 'rgba(245, 158, 11, 0.4)');
  gulfGrad.addColorStop(1, 'rgba(6, 182, 212, 0)');
  ctx.fillStyle = gulfGrad;
  ctx.beginPath();
  ctx.arc(w * 0.32, h * 0.34, w * 0.14, 0, Math.PI * 2);
  ctx.fill();

  // Marine Heatwave hotspots (pulsing with frameIndex)
  const hotspots = [
    { x: w * 0.08, y: h * 0.38, r: w * 0.06, label: 'NE Pacific Heat Blob' },
    { x: w * 0.65, y: h * 0.58, r: w * 0.08, label: 'Indian Ocean Anomaly' },
    { x: w * 0.88, y: h * 0.68, r: w * 0.07, label: 'Tasman Sea Heatwave' }
  ];

  hotspots.forEach((spot, i) => {
    const pulse = Math.sin(t + i * 2) * 0.2 + 0.8;
    const g = ctx.createRadialGradient(spot.x, spot.y, 2, spot.x, spot.y, spot.r * pulse);
    g.addColorStop(0, 'rgba(255, 255, 255, 0.8)');
    g.addColorStop(0.3, 'rgba(239, 68, 68, 0.7)');
    g.addColorStop(0.8, 'rgba(245, 158, 11, 0.3)');
    g.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(spot.x, spot.y, spot.r * pulse, 0, Math.PI * 2);
    ctx.fill();
  });

  ctx.restore();
}

/**
 * 2. Atmospheric CO2 & Emission Plumes
 */
function drawCO2Layer(ctx, w, h, t, frameIndex) {
  ctx.save();
  ctx.globalCompositeOperation = 'screen';

  // Seasonal global baseline modulation (higher in winter/spring, lower in late summer)
  const seasonalFactor = Math.sin(t - Math.PI / 4) * 0.5 + 0.5; // 0 (summer min) to 1 (winter peak)

  // Northern Hemisphere CO2 accumulation veil
  const nhGrad = ctx.createLinearGradient(0, 0, 0, h * 0.6);
  nhGrad.addColorStop(0, `rgba(234, 88, 12, ${0.4 + seasonalFactor * 0.35})`);
  nhGrad.addColorStop(0.5, `rgba(234, 179, 8, ${0.3 + seasonalFactor * 0.2})`);
  nhGrad.addColorStop(1, 'rgba(4, 120, 87, 0.1)');
  ctx.fillStyle = nhGrad;
  ctx.fillRect(0, 0, w, h * 0.6);

  // Intense industrial plumes
  const plumes = [
    { x: w * 0.22, y: h * 0.34, rx: w * 0.09, ry: h * 0.08, name: 'North America Corridor' },
    { x: w * 0.50, y: h * 0.28, rx: w * 0.08, ry: h * 0.07, name: 'Western & Central Europe' },
    { x: w * 0.76, y: h * 0.35, rx: w * 0.12, ry: h * 0.09, name: 'East Asian Industrial Belt' },
    { x: w * 0.70, y: h * 0.45, rx: w * 0.06, ry: h * 0.06, name: 'Indo-Gangetic Plain' }
  ];

  plumes.forEach((p, idx) => {
    const plumeIntensity = 0.5 + seasonalFactor * 0.4 + Math.sin(t * 2 + idx) * 0.1;
    const g = ctx.createRadialGradient(p.x, p.y, 5, p.x, p.y, p.rx);
    g.addColorStop(0, `rgba(220, 38, 38, ${plumeIntensity})`);
    g.addColorStop(0.4, `rgba(234, 88, 12, ${plumeIntensity * 0.8})`);
    g.addColorStop(0.8, `rgba(234, 179, 8, ${plumeIntensity * 0.4})`);
    g.addColorStop(1, 'rgba(0, 0, 0, 0)');

    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(p.x, p.y, p.rx, p.ry, 0, 0, Math.PI * 2);
    ctx.fill();
  });

  // Southern Hemisphere seasonal biomass burning plumes (Amazon & Central Africa in southern dry season)
  const southernBurnFactor = Math.cos(t) * 0.5 + 0.5; // active late austral winter/spring
  if (southernBurnFactor > 0.3) {
    const sPlumes = [
      { x: w * 0.30, y: h * 0.62, r: w * 0.07 }, // Amazon Arc of Deforestation
      { x: w * 0.54, y: h * 0.60, r: w * 0.08 }  // African Savanna fires
    ];
    sPlumes.forEach(sp => {
      const g = ctx.createRadialGradient(sp.x, sp.y, 4, sp.x, sp.y, sp.r * southernBurnFactor);
      g.addColorStop(0, `rgba(234, 88, 12, ${0.7 * southernBurnFactor})`);
      g.addColorStop(0.6, `rgba(234, 179, 8, ${0.4 * southernBurnFactor})`);
      g.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(sp.x, sp.y, sp.r * southernBurnFactor, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  ctx.restore();
}

/**
 * 3. Polar Sea Ice Extent (Decadal Shrinkage)
 */
function drawSeaIceLayer(ctx, w, h, frameIndex, totalFrames) {
  ctx.save();

  // Progress from 1980 (dense extensive ice) to 2024 (fragmented minimum ice)
  const lossProgress = frameIndex / (totalFrames - 1); // 0.0 (1980) to 1.0 (2024)
  const arcticShrink = 1.0 - lossProgress * 0.55; // 100% down to 45% of baseline extent
  const antarcticMod = 1.0 - Math.sin(lossProgress * Math.PI) * 0.2;

  // Arctic Sea Ice Cap (North Pole)
  const arcticCenterX = w * 0.48;
  const arcticCenterY = h * 0.12;
  const arcticRadiusX = w * 0.28 * arcticShrink;
  const arcticRadiusY = h * 0.14 * arcticShrink;

  // Multi-year pack ice core
  const iceGrad = ctx.createRadialGradient(
    arcticCenterX, arcticCenterY, 5,
    arcticCenterX, arcticCenterY, arcticRadiusX
  );
  iceGrad.addColorStop(0, '#ffffff'); // Thick white pack
  iceGrad.addColorStop(0.4, '#e0f2fe'); // Compact consolidated ice
  iceGrad.addColorStop(0.8, '#38bdf8'); // Seasonal marginal ice
  iceGrad.addColorStop(1, 'rgba(2, 132, 199, 0)'); // Open ocean edge

  ctx.fillStyle = iceGrad;
  ctx.beginPath();
  ctx.ellipse(arcticCenterX, arcticCenterY, arcticRadiusX, arcticRadiusY, 0, 0, Math.PI * 2);
  ctx.fill();

  // Antarctic Sea Ice Collar (South Pole)
  const antarcticHeight = h * 0.15 * antarcticMod;
  const antGrad = ctx.createLinearGradient(0, h - antarcticHeight, 0, h);
  antGrad.addColorStop(0, 'rgba(56, 189, 248, 0)');
  antGrad.addColorStop(0.3, '#38bdf8');
  antGrad.addColorStop(0.7, '#e0f2fe');
  antGrad.addColorStop(1, '#ffffff');

  ctx.fillStyle = antGrad;
  ctx.fillRect(0, h - antarcticHeight, w, antarcticHeight);

  // Ice cracks / leads texture in modern years
  if (lossProgress > 0.4) {
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.7)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(arcticCenterX - arcticRadiusX * 0.4, arcticCenterY);
    ctx.lineTo(arcticCenterX + arcticRadiusX * 0.3, arcticCenterY + 10);
    ctx.moveTo(arcticCenterX - 10, arcticCenterY - 15);
    ctx.lineTo(arcticCenterX + 15, arcticCenterY + 20);
    ctx.stroke();
  }

  ctx.restore();
}

/**
 * 4. Biosphere & Vegetation Index (NDVI Green Wave)
 */
function drawNDVILayer(ctx, w, h, t, frameIndex) {
  ctx.save();
  ctx.globalCompositeOperation = 'source-over';

  // Northern green wave phase
  const greenWave = Math.sin(t - Math.PI / 3) * 0.5 + 0.5; // peaks in July/August

  // Amazon Rainforest (Persistent dense emerald green)
  const amazonGrad = ctx.createRadialGradient(w * 0.30, h * 0.60, 10, w * 0.30, h * 0.60, w * 0.10);
  amazonGrad.addColorStop(0, '#052e16');
  amazonGrad.addColorStop(0.5, '#15803d');
  amazonGrad.addColorStop(0.9, '#84cc16');
  amazonGrad.addColorStop(1, 'rgba(132, 204, 22, 0)');
  ctx.fillStyle = amazonGrad;
  ctx.beginPath();
  ctx.arc(w * 0.30, h * 0.60, w * 0.10, 0, Math.PI * 2);
  ctx.fill();

  // Congo Rainforest
  const congoGrad = ctx.createRadialGradient(w * 0.52, h * 0.55, 5, w * 0.52, h * 0.55, w * 0.07);
  congoGrad.addColorStop(0, '#052e16');
  congoGrad.addColorStop(0.6, '#15803d');
  congoGrad.addColorStop(1, 'rgba(21, 128, 61, 0)');
  ctx.fillStyle = congoGrad;
  ctx.beginPath();
  ctx.arc(w * 0.52, h * 0.55, w * 0.07, 0, Math.PI * 2);
  ctx.fill();

  // Southeast Asian & Indonesian archipelagos
  const seaGrad = ctx.createRadialGradient(w * 0.78, h * 0.58, 5, w * 0.78, h * 0.58, w * 0.08);
  seaGrad.addColorStop(0, '#052e16');
  seaGrad.addColorStop(0.6, '#15803d');
  seaGrad.addColorStop(1, 'rgba(21, 128, 61, 0)');
  ctx.fillStyle = seaGrad;
  ctx.beginPath();
  ctx.arc(w * 0.78, h * 0.58, w * 0.08, 0, Math.PI * 2);
  ctx.fill();

  // Northern Taiga & Boreal Forest Green Wave (Canada, Scandinavia, Siberia)
  // Expands vibrantly in summer, turns muted dormant brown in winter
  const taigaColor = greenWave > 0.5 ? '#15803d' : '#ca8a04';
  const taigaAlpha = 0.3 + greenWave * 0.5;

  ctx.fillStyle = taigaColor;
  ctx.globalAlpha = taigaAlpha;

  // Canadian Taiga
  ctx.beginPath();
  ctx.ellipse(w * 0.22, h * 0.22, w * 0.12, h * 0.06, -0.1, 0, Math.PI * 2);
  ctx.fill();

  // Eurasian Taiga
  ctx.beginPath();
  ctx.ellipse(w * 0.65, h * 0.20, w * 0.22, h * 0.07, 0.05, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

/**
 * 5. Earth at Night (VIIRS Black Marble)
 */
function drawNightLightsLayer(ctx, w, h, frameIndex) {
  ctx.save();

  // Dark nocturnal oceans and wilderness
  ctx.fillStyle = '#020617';
  ctx.fillRect(0, 0, w, h);

  // Faint landmass tint
  ctx.fillStyle = '#090e24';
  drawContinents(ctx, w, h);

  // Electrical luminescence clusters
  const cities = [
    // North America Megalopolis & Grid
    { x: w * 0.25, y: h * 0.33, r: 14, brightness: 1.0, label: 'US East Coast' },
    { x: w * 0.21, y: h * 0.34, r: 10, brightness: 0.9, label: 'Chicago & Midwest' },
    { x: w * 0.13, y: h * 0.37, r: 12, brightness: 0.9, label: 'California' },
    { x: w * 0.19, y: h * 0.43, r: 8, brightness: 0.8, label: 'Texas / Gulf' },
    // Europe
    { x: w * 0.48, y: h * 0.28, r: 16, brightness: 1.0, label: 'London/Paris/Rhine' },
    { x: w * 0.52, y: h * 0.32, r: 10, brightness: 0.85, label: 'Po Valley / Italy' },
    { x: w * 0.55, y: h * 0.24, r: 8, brightness: 0.8, label: 'Moscow' },
    // Asia
    { x: w * 0.77, y: h * 0.36, r: 16, brightness: 1.0, label: 'Beijing / Shanghai' },
    { x: w * 0.75, y: h * 0.42, r: 15, brightness: 1.0, label: 'Pearl River Delta' },
    { x: w * 0.85, y: h * 0.35, r: 14, brightness: 1.0, label: 'Tokyo / Osaka' },
    { x: w * 0.80, y: h * 0.34, r: 11, brightness: 0.95, label: 'Seoul' },
    { x: w * 0.68, y: h * 0.43, r: 13, brightness: 0.9, label: 'Delhi & Ganges' },
    // Middle East & Africa
    { x: w * 0.55, y: h * 0.43, r: 10, brightness: 0.9, label: 'Nile River Corridor' },
    { x: w * 0.60, y: h * 0.44, r: 11, brightness: 0.85, label: 'Persian Gulf' },
    // South America & Australia
    { x: w * 0.34, y: h * 0.72, r: 12, brightness: 0.85, label: 'São Paulo / Rio' },
    { x: w * 0.30, y: h * 0.76, r: 9, brightness: 0.8, label: 'Buenos Aires' },
    { x: w * 0.84, y: h * 0.75, r: 10, brightness: 0.85, label: 'Sydney / Melbourne' }
  ];

  ctx.globalCompositeOperation = 'screen';

  cities.forEach(city => {
    // Outer golden glow
    const g1 = ctx.createRadialGradient(city.x, city.y, 1, city.x, city.y, city.r * 2.5);
    g1.addColorStop(0, 'rgba(254, 240, 138, 0.9)');
    g1.addColorStop(0.3, 'rgba(245, 158, 11, 0.6)');
    g1.addColorStop(0.7, 'rgba(180, 83, 9, 0.2)');
    g1.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = g1;
    ctx.beginPath();
    ctx.arc(city.x, city.y, city.r * 2.5, 0, Math.PI * 2);
    ctx.fill();

    // Intense white/gold incandescent core
    const g2 = ctx.createRadialGradient(city.x, city.y, 0, city.x, city.y, city.r * 0.7);
    g2.addColorStop(0, '#ffffff');
    g2.addColorStop(0.5, '#fef08a');
    g2.addColorStop(1, 'rgba(254, 240, 138, 0)');
    ctx.fillStyle = g2;
    ctx.beginPath();
    ctx.arc(city.x, city.y, city.r * 0.7, 0, Math.PI * 2);
    ctx.fill();
  });

  // Interconnecting electrical network filaments
  ctx.strokeStyle = 'rgba(245, 158, 11, 0.25)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  // US grid
  ctx.moveTo(w * 0.25, h * 0.33); ctx.lineTo(w * 0.21, h * 0.34);
  ctx.lineTo(w * 0.19, h * 0.43); ctx.lineTo(w * 0.13, h * 0.37);
  // Europe grid
  ctx.moveTo(w * 0.48, h * 0.28); ctx.lineTo(w * 0.52, h * 0.32);
  ctx.lineTo(w * 0.55, h * 0.24);
  // East Asia
  ctx.moveTo(w * 0.77, h * 0.36); ctx.lineTo(w * 0.75, h * 0.42);
  ctx.stroke();

  ctx.restore();
}

/**
 * 6. Ozone Layer Hole & Polar Vortex
 */
function drawOzoneLayer(ctx, w, h, t, frameIndex) {
  ctx.save();
  ctx.globalCompositeOperation = 'screen';

  // Surrounding healthy ozone reservoir (rich cyan to golden ring)
  const collarGrad = ctx.createRadialGradient(w * 0.5, h * 0.85, w * 0.05, w * 0.5, h * 0.85, w * 0.35);
  collarGrad.addColorStop(0, 'rgba(76, 29, 149, 0)');
  collarGrad.addColorStop(0.35, 'rgba(6, 182, 212, 0.4)');
  collarGrad.addColorStop(0.65, 'rgba(234, 179, 8, 0.6)');
  collarGrad.addColorStop(0.85, 'rgba(239, 68, 68, 0.5)');
  collarGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = collarGrad;
  ctx.beginPath();
  ctx.arc(w * 0.5, h * 0.85, w * 0.35, 0, Math.PI * 2);
  ctx.fill();

  // The Antarctic Ozone Hole (Deep purple/indigo void)
  const holePhase = Math.sin(t) * 0.5 + 0.5; // expansion/contraction
  const holeRadius = w * 0.14 * (0.8 + holePhase * 0.4);

  const holeGrad = ctx.createRadialGradient(w * 0.5, h * 0.88, 5, w * 0.5, h * 0.88, holeRadius);
  holeGrad.addColorStop(0, '#4c1d95');
  holeGrad.addColorStop(0.6, '#312e81');
  holeGrad.addColorStop(0.85, '#1e3a8a');
  holeGrad.addColorStop(1, 'rgba(30, 58, 138, 0)');

  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = holeGrad;
  ctx.beginPath();
  ctx.ellipse(w * 0.5, h * 0.88, holeRadius, holeRadius * 0.75, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

/**
 * Scientific Latitude/Longitude Graticule & HUD
 */
function drawScientificGrid(ctx, w, h) {
  ctx.save();
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.12)';
  ctx.lineWidth = 1;

  // Equator line (slightly emphasized)
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.25)';
  ctx.beginPath();
  ctx.moveTo(0, h * 0.5);
  ctx.lineTo(w, h * 0.5);
  ctx.stroke();

  // Latitudes
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.08)';
  [0.2, 0.35, 0.65, 0.8].forEach(latY => {
    ctx.beginPath();
    ctx.moveTo(0, h * latY);
    ctx.lineTo(w, h * latY);
    ctx.stroke();
  });

  // Longitudes
  for (let i = 1; i < 8; i++) {
    const longX = (w / 8) * i;
    ctx.beginPath();
    ctx.moveTo(longX, 0);
    ctx.lineTo(longX, h);
    ctx.stroke();
  }

  // Corner HUD crosses
  const d = 8;
  const drawCross = (x, y) => {
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.4)';
    ctx.beginPath();
    ctx.moveTo(x - d, y); ctx.lineTo(x + d, y);
    ctx.moveTo(x, y - d); ctx.lineTo(x, y + d);
    ctx.stroke();
  };
  drawCross(20, 20);
  drawCross(w - 20, 20);
  drawCross(20, h - 20);
  drawCross(w - 20, h - 20);

  ctx.restore();
}

/**
 * Glowing Scan Beam (Orbital / Longitudinal Scan)
 */
function drawScanBeam(ctx, w, h, scanPosition) {
  ctx.save();
  const scanX = scanPosition * w;

  // Beam gradient
  const beamGrad = ctx.createLinearGradient(scanX - 25, 0, scanX + 25, 0);
  beamGrad.addColorStop(0, 'rgba(0, 240, 255, 0)');
  beamGrad.addColorStop(0.5, 'rgba(0, 240, 255, 0.45)');
  beamGrad.addColorStop(1, 'rgba(0, 240, 255, 0)');

  ctx.fillStyle = beamGrad;
  ctx.fillRect(scanX - 25, 0, 50, h);

  // Sharp center laser line
  ctx.strokeStyle = '#00f0ff';
  ctx.lineWidth = 2;
  ctx.shadowColor = '#00f0ff';
  ctx.shadowBlur = 12;
  ctx.beginPath();
  ctx.moveTo(scanX, 0);
  ctx.lineTo(scanX, h);
  ctx.stroke();

  // Scan position reticle
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(scanX, h * 0.5, 4, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}
