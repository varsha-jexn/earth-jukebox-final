# 🌌 NASA Earth Jukebox: Sight-to-Sound Sonification Experience

> **NASA Earth Information Center (EIC) Challenge Project**  
> Translating Earth science visual frames into dynamic, real-time auditory soundscapes to make planetary data accessible, engaging, and multi-sensory for blind, low-vision, and general audiences.

![Earth Jukebox NASA Theme](https://img.shields.io/badge/Theme-Deep%20Navy%20Cosmic-0b3d91)
![Web Audio API](https://img.shields.io/badge/Audio-Web%20Audio%20API-00f0ff)
![Accessibility](https://img.shields.io/badge/Accessibility-Screen%20Reader%20%7C%20TTS%20%7C%20High%20Contrast-10b981)
![License](https://img.shields.io/badge/License-MIT-blue)

---

## 🛰️ Project Overview

NASA’s Earth Information Center produces stunning visualizations of our changing planet, tracking everything from shifting sea surface temperatures to evolving atmospheric carbon dioxide plumes. However, presenting vital Earth science exclusively through visual media limits who can engage with it.

**Earth Jukebox** bridges this sensory gap through **real-time optical sonification**. By analyzing satellite imagery frames with computer vision and driving Web Audio synthesizers with scientific rulesets, Earth Jukebox transforms planetary dynamics into rich, musically pleasing, and scientifically grounded auditory experiences.

---

## ✨ Key Features

- **Deep Navy Blue Aesthetic**: Designed with a deep space navy blue palette (`#030712`, `#060e24`, `#0d1e44`), glowing cyan/electric azure accents, NASA head-up displays (HUD), and an animated twinkling starfield canvas.
- **Fully Working Authentication & User Library**:
  - **Sign Up**: Register with custom preferences (synth engine, scale, screen-reader telemetry, high-contrast mode).
  - **Log In**: Form validation with persistent sessions via `localStorage`, plus a **1-Click Demo Explorer** button to test instantly as *Dr. Elena Vance (NASA Climate Sonification Fellow)*.
  - **User Library**: Save favorite soundscapes, view play history, and manage custom audio presets.
- **6 Curated NASA EIC Datasets**:
  1. *Global Sea Surface Temperature (SST) & Thermal Anomalies* (Terra/Aqua MODIS, Sentinel-3 SLSTR)
  2. *Atmospheric Carbon Dioxide & Emission Plumes* (OCO-2, Goddard GEOS)
  3. *Polar Sea Ice Extent (1980–2024 Cryosphere Shrinkage)* (Nimbus-7, DMSP, ICESat-2)
  4. *Global Biosphere & Normalized Difference Vegetation Index (NDVI)* (MODIS, VIIRS)
  5. *Earth at Night: Global Energy & Luminescence* (Suomi NPP VIIRS Day/Night Band)
  6. *Antarctic Ozone Layer & Stratospheric Recovery* (Aura OMI, Sentinel-5P TROPOMI)
- **Custom Satellite Frame Uploader**: Upload any satellite photo, weather capture, or planetary graphic for instant computer vision analysis and sonification.
- **Sight-to-Sound Synthesis Engine**:
  - Built with native browser **Web Audio API** (zero third-party audio dependencies).
  - 5 Synthesizer Engines: *Ocean Drone*, *Cosmic Ambient*, *Chime Marimba*, *Cybernetic Pulse*, and *Solar Shimmer*.
  - 5 Musical Scales: *Lydian*, *Dorian*, *Minor Pentatonic*, *Major Pentatonic*, and *Chromatic Tension*.
  - **Interactive Coordinate Probe**: Click or hover over any spot on the globe to inspect coordinates and trigger a localized crystal harmonic triad.
- **Real-Time Visualizers & Live Audio Recording**:
  - Live time-domain Oscilloscope and FFT Frequency Spectrum analyzer.
  - Live Audio Recorder captures output directly and downloads `.webm`/`.wav` audio.
- **Accessibility for Blind & Low-Vision Users**:
  - `aria-live` dynamic screen-reader announcements for real-time telemetry.
  - Spoken Audio Description (Text-to-Speech narration of planetary features).
  - High Contrast Mode toggle and full keyboard navigation (`Space`, `←`/`→`, `M`, `R`, `?`).

---

## 🎛️ Sight-to-Sound Translation Ruleset

- **Hue (0°–360°)** $\to$ **Musical Pitch**: Maps into quantized musical scales. Cool oceanic blues voice deep fundamental roots; biosphere greens trigger warm mid woodwinds; thermal reds voice high-energy leads and urgent climate alerts.
- **Luminance & Density** $\to$ **Filter Cutoff & Velocity**: Bright pixels (such as ice caps, storm clouds, or metropolitan night lights) open the low-pass filter up to 4,500 Hz, adding brilliance and clarity.
- **Coordinates (X, Y)** $\to$ **Spatial Audio & Register**: Longitude drives stereo panning (-1.0 West to +1.0 East); latitude shifts register octaves (Arctic treble to Antarctic sub-bass).

---

## 🚀 Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) (v16 or higher)

### Installation & Run

1. Clone or download the repository:
   ```bash
   git clone https://github.com/<your-username>/earth-jukebox.git
   cd earth-jukebox
   ```

2. Start the local server:
   ```bash
   node server.js
   ```

3. Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

*Alternatively, you can open `index.html` directly in any modern browser that supports ES modules.*

---

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
| :--- | :--- |
| `Space` | Start / Stop Sonification |
| `←` / `→` | Step Previous / Next Time-Series Frame |
| `M` | Toggle Audio Mute |
| `R` | Start / Stop Live Audio Recording |
| `?` or `H` | Open Help & Accessibility Guide |

---

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🛰️ Acknowledgments

- **NASA Earth Information Center (EIC)** for Earth observation data and missions.
- **NASA Earthdata** (MODIS, VIIRS, OCO-2, ICESat-2, OMI).
