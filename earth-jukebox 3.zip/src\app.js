/**
 * NASA Earth Jukebox - Main Application Orchestrator
 * Connects Canvas rendering, Web Audio synthesis, Authentication, and Accessibility.
 */

import { EIC_DATASETS } from './datasets.js';
import { EarthAudioEngine } from './audio-engine.js';
import { EarthVisualEngine } from './visual-engine.js';
import { AuthStore } from './auth-store.js';
import { AccessibilityService } from './accessibility.js';

class EarthJukeboxApp {
  constructor() {
    this.audio = new EarthAudioEngine();
    this.auth = new AuthStore();
    this.a11y = new AccessibilityService();

    // App State
    this.currentDataset = EIC_DATASETS[0];
    this.currentFrameIndex = 0;
    this.isPlayingFrames = false;
    this.frameTimer = null;
    this.frameSpeedMs = 1200; // ms per frame
    this.isSonifying = false;
    this.scanSpeedMultiplier = 1.0;

    // Recording timer
    this.recordingInterval = null;
    this.recordingSeconds = 0;

    // Elements
    this.mainCanvas = document.getElementById('earth-canvas');
    this.scopeCanvas = document.getElementById('oscilloscope-canvas');
    this.spectrumCanvas = document.getElementById('spectrum-canvas');
    this.starCanvas = document.getElementById('stars-canvas');

    this.visual = new EarthVisualEngine(this.mainCanvas);

    // Audio Visualizer Contexts
    this.scopeCtx = this.scopeCanvas ? this.scopeCanvas.getContext('2d') : null;
    this.spectrumCtx = this.spectrumCanvas ? this.spectrumCanvas.getContext('2d') : null;
    this.starCtx = this.starCanvas ? this.starCanvas.getContext('2d') : null;

    // Starfield particles
    this.stars = [];
    this.initStarfield();

    // Audio analysis buffers
    this.freqData = new Uint8Array(64);
    this.timeData = new Uint8Array(128);

    // Last slice audio trigger throttle
    this.lastAudioTriggerTime = 0;
    this.audioTriggerInterval = 120; // ms between slices

    this.init();
  }

  async init() {
    this.setupEventListeners();
    this.setupAuthListeners();
    this.setupDatasetList();
    this.loadDataset(this.currentDataset.id);
    this.resizeCanvases();
    window.addEventListener('resize', () => this.resizeCanvases());

    // Start main animation loop
    requestAnimationFrame((t) => this.animationLoop(t));
  }

  /**
   * Starfield background canvas
   */
  initStarfield() {
    if (!this.starCanvas) return;
    this.starCanvas.width = window.innerWidth;
    this.starCanvas.height = window.innerHeight;
    this.stars = [];
    const count = Math.floor((window.innerWidth * window.innerHeight) / 9000);
    for (let i = 0; i < count; i++) {
      this.stars.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        r: Math.random() * 1.5 + 0.4,
        alpha: Math.random() * 0.8 + 0.2,
        twinkleSpeed: Math.random() * 0.02 + 0.005
      });
    }
  }

  resizeCanvases() {
    if (this.starCanvas) {
      this.starCanvas.width = window.innerWidth;
      this.starCanvas.height = window.innerHeight;
    }

    const container = document.getElementById('canvas-wrapper');
    if (container && this.mainCanvas) {
      const rect = container.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.floor(rect.width);
      const h = Math.floor(rect.height);

      this.visual.resize(w, h);
    }

    if (this.scopeCanvas) {
      this.scopeCanvas.width = this.scopeCanvas.parentElement.clientWidth;
      this.scopeCanvas.height = 70;
    }
    if (this.spectrumCanvas) {
      this.spectrumCanvas.width = this.spectrumCanvas.parentElement.clientWidth;
      this.spectrumCanvas.height = 70;
    }
  }

  /**
   * Main 60 FPS Animation & Sonification Loop
   */
  animationLoop(timestamp) {
    // 1. Draw Starfield
    this.renderStars();

    // 2. Render Satellite Visual Frame & Scanbeam
    if (this.isSonifying) {
      this.visual.tickScan(this.scanSpeedMultiplier);
    }
    this.visual.render(this.currentDataset.id, this.currentFrameIndex);

    // 3. Computer Vision Slice Analysis & Sonification Trigger
    if (this.isSonifying && timestamp - this.lastAudioTriggerTime > this.audioTriggerInterval) {
      const sliceMetrics = this.visual.analyzeCurrentSlice();
      if (sliceMetrics) {
        this.audio.playSliceSonification(sliceMetrics, sliceMetrics.panX);
        this.updateHUDMetrics(sliceMetrics);
      }
      this.lastAudioTriggerTime = timestamp;
    }

    // 4. Render Oscilloscope & Spectrum Visualizers
    this.renderAudioVisualizers();

    requestAnimationFrame((t) => this.animationLoop(t));
  }

  renderStars() {
    if (!this.starCtx || !this.starCanvas) return;
    this.starCtx.clearRect(0, 0, this.starCanvas.width, this.starCanvas.height);

    for (let s of this.stars) {
      s.alpha += Math.sin(Date.now() * s.twinkleSpeed) * 0.01;
      const a = Math.max(0.1, Math.min(0.9, s.alpha));
      this.starCtx.fillStyle = `rgba(224, 242, 254, ${a})`;
      this.starCtx.beginPath();
      this.starCtx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      this.starCtx.fill();
    }
  }

  renderAudioVisualizers() {
    if (!this.audio.ctx) return;

    // Waveform Oscilloscope
    if (this.scopeCtx && this.scopeCanvas) {
      const w = this.scopeCanvas.width;
      const h = this.scopeCanvas.height;
      this.audio.getTimeDomainData(this.timeData);

      this.scopeCtx.fillStyle = 'rgba(3, 11, 30, 0.4)';
      this.scopeCtx.fillRect(0, 0, w, h);

      this.scopeCtx.lineWidth = 2;
      this.scopeCtx.strokeStyle = '#00f0ff';
      this.scopeCtx.shadowColor = '#00f0ff';
      this.scopeCtx.shadowBlur = 6;
      this.scopeCtx.beginPath();

      const sliceWidth = w / this.timeData.length;
      let x = 0;
      for (let i = 0; i < this.timeData.length; i++) {
        const v = this.timeData[i] / 128.0;
        const y = (v * h) / 2;
        if (i === 0) this.scopeCtx.moveTo(x, y);
        else this.scopeCtx.lineTo(x, y);
        x += sliceWidth;
      }
      this.scopeCtx.stroke();
      this.scopeCtx.shadowBlur = 0;
    }

    // Frequency Spectrum Bars
    if (this.spectrumCtx && this.spectrumCanvas) {
      const w = this.spectrumCanvas.width;
      const h = this.spectrumCanvas.height;
      this.audio.getFrequencyData(this.freqData);

      this.spectrumCtx.fillStyle = 'rgba(3, 11, 30, 0.4)';
      this.spectrumCtx.fillRect(0, 0, w, h);

      const barWidth = (w / this.freqData.length) * 0.9;
      let x = 0;

      for (let i = 0; i < this.freqData.length; i++) {
        const barHeight = (this.freqData[i] / 255) * h;
        const grad = this.spectrumCtx.createLinearGradient(0, h, 0, h - barHeight);
        grad.addColorStop(0, '#0284c7');
        grad.addColorStop(0.6, '#00f0ff');
        grad.addColorStop(1, '#f59e0b');

        this.spectrumCtx.fillStyle = grad;
        this.spectrumCtx.fillRect(x, h - barHeight, barWidth, barHeight);
        x += barWidth + 1.5;
      }
    }
  }

  updateHUDMetrics(metrics) {
    const longEl = document.getElementById('hud-longitude');
    const freqEl = document.getElementById('hud-freq');
    const colorSwatch = document.getElementById('hud-color-swatch');
    const densityMeter = document.getElementById('hud-density-fill');
    const noteEl = document.getElementById('hud-current-note');

    if (longEl) {
      const lon = ((metrics.xPosition * 360) - 180).toFixed(0);
      longEl.textContent = `${Math.abs(lon)}° ${lon >= 0 ? 'E' : 'W'}`;
    }
    if (freqEl) {
      const approxHz = Math.round(metrics.luminance * 1200 + 130);
      freqEl.textContent = `${approxHz} Hz`;
    }
    if (colorSwatch) {
      colorSwatch.style.backgroundColor = `hsl(${metrics.dominantHue}, ${Math.round(metrics.saturation * 100)}%, ${Math.round(metrics.lightness * 100)}%)`;
    }
    if (densityMeter) {
      densityMeter.style.width = `${Math.min(100, Math.round(metrics.density * 180))}%`;
    }
    if (noteEl) {
      const noteNames = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
      const noteIdx = Math.floor((metrics.dominantHue / 360) * 12) % 12;
      noteEl.textContent = noteNames[noteIdx];
    }
  }

  /**
   * Set up UI Event Listeners
   */
  setupEventListeners() {
    // 1. Master Sonification Toggle
    const playBtn = document.getElementById('btn-play-sonification');
    if (playBtn) {
      playBtn.addEventListener('click', async () => {
        await this.audio.ensureRunning();
        this.isSonifying = !this.isSonifying;
        this.updatePlayButtonState();
        if (this.isSonifying) {
          this.a11y.announce(`Sonification active for ${this.currentDataset.title}`);
        }
      });
    }

    // 2. Frame Time-Series Controls
    const animToggleBtn = document.getElementById('btn-toggle-animation');
    if (animToggleBtn) {
      animToggleBtn.addEventListener('click', () => this.toggleFrameAnimation());
    }

    const prevFrameBtn = document.getElementById('btn-prev-frame');
    if (prevFrameBtn) {
      prevFrameBtn.addEventListener('click', () => this.stepFrame(-1));
    }

    const nextFrameBtn = document.getElementById('btn-next-frame');
    if (nextFrameBtn) {
      nextFrameBtn.addEventListener('click', () => this.stepFrame(1));
    }

    const frameSlider = document.getElementById('frame-slider');
    if (frameSlider) {
      frameSlider.addEventListener('input', (e) => {
        this.currentFrameIndex = parseInt(e.target.value, 10);
        this.updateFrameDisplay();
      });
    }

    // 3. Audio Synth & Scale Selectors
    const synthSelect = document.getElementById('synth-select');
    if (synthSelect) {
      synthSelect.addEventListener('change', (e) => {
        this.audio.setSynth(e.target.value);
        this.a11y.announce(`Synthesizer changed to ${e.target.options[e.target.selectedIndex].text}`);
      });
    }

    const scaleSelect = document.getElementById('scale-select');
    if (scaleSelect) {
      scaleSelect.addEventListener('change', (e) => {
        this.audio.setScale(e.target.value);
        this.a11y.announce(`Harmonic scale set to ${e.target.options[e.target.selectedIndex].text}`);
      });
    }

    // 4. Volume & Mute
    const volSlider = document.getElementById('volume-slider');
    if (volSlider) {
      volSlider.addEventListener('input', (e) => {
        this.audio.setVolume(parseFloat(e.target.value));
      });
    }

    const muteBtn = document.getElementById('btn-mute');
    if (muteBtn) {
      muteBtn.addEventListener('click', () => {
        const muted = this.audio.toggleMute();
        muteBtn.classList.toggle('muted', muted);
        muteBtn.setAttribute('aria-pressed', muted);
        muteBtn.title = muted ? 'Unmute Audio' : 'Mute Audio';
        this.a11y.announce(muted ? 'Audio muted' : 'Audio unmuted');
      });
    }

    // 5. Scan Speed Multiplier
    const speedSelect = document.getElementById('scan-speed-select');
    if (speedSelect) {
      speedSelect.addEventListener('change', (e) => {
        this.scanSpeedMultiplier = parseFloat(e.target.value);
      });
    }

    // 6. Interactive Coordinate Probe on Canvas Hover / Click
    if (this.mainCanvas) {
      const probeTooltip = document.getElementById('probe-tooltip');

      const handleProbe = async (clientX, clientY) => {
        const point = this.visual.analyzePoint(clientX, clientY);
        if (!point) return;

        // Play crystal probe chord
        await this.audio.ensureRunning();
        this.audio.playPointProbe(point.hue, point.sat, point.lightness, point.xNorm, point.yNorm);

        // Update Probe Tooltip
        if (probeTooltip) {
          const rect = this.mainCanvas.getBoundingClientRect();
          probeTooltip.style.display = 'block';
          probeTooltip.style.left = `${clientX - rect.left + 15}px`;
          probeTooltip.style.top = `${clientY - rect.top + 15}px`;
          probeTooltip.innerHTML = `
            <div class="tooltip-title">${point.latitude}, ${point.longitude}</div>
            <div class="tooltip-row">
              <span class="swatch" style="background: rgb(${point.r}, ${point.g}, ${point.b})"></span>
              <span>RGB(${point.r}, ${point.g}, ${point.b})</span>
            </div>
            <div class="tooltip-row">Lum: ${Math.round(point.lum * 100)}% | Freq: ~${Math.round(point.lum * 1200 + 130)}Hz</div>
          `;
        }
      };

      this.mainCanvas.addEventListener('click', (e) => {
        handleProbe(e.clientX, e.clientY);
      });

      this.mainCanvas.addEventListener('mousemove', (e) => {
        if (e.buttons === 1) { // While dragging/clicking
          handleProbe(e.clientX, e.clientY);
        }
      });

      this.mainCanvas.addEventListener('mouseleave', () => {
        if (probeTooltip) probeTooltip.style.display = 'none';
      });
    }

    // 7. Live Audio Recorder
    const recordBtn = document.getElementById('btn-record-audio');
    if (recordBtn) {
      recordBtn.addEventListener('click', () => this.toggleRecording());
    }

    // 8. Custom Satellite Image Uploader
    const uploadInput = document.getElementById('custom-image-input');
    const uploadBtn = document.getElementById('btn-upload-trigger');
    if (uploadBtn && uploadInput) {
      uploadBtn.addEventListener('click', () => uploadInput.click());
      uploadInput.addEventListener('change', (e) => this.handleCustomImageUpload(e));
    }

    // 9. Accessibility TTS Audio Narration
    const narrateBtn = document.getElementById('btn-audio-narration');
    if (narrateBtn) {
      narrateBtn.addEventListener('click', () => {
        const active = !this.a11y.isTTSActive;
        this.a11y.setTTS(active);
        narrateBtn.classList.toggle('active', active);
        narrateBtn.setAttribute('aria-pressed', active);
        if (active) {
          const text = `${this.currentDataset.title}. ${this.currentDataset.narrative(this.currentFrameIndex)}`;
          this.a11y.speak(text);
        } else {
          this.a11y.stopSpeaking();
        }
      });
    }

    // 10. High Contrast Mode Toggle
    const contrastBtn = document.getElementById('btn-high-contrast');
    if (contrastBtn) {
      contrastBtn.addEventListener('click', () => {
        const isHC = this.a11y.toggleHighContrast();
        contrastBtn.classList.toggle('active', isHC);
        contrastBtn.setAttribute('aria-pressed', isHC);
      });
    }

    // 11. Keyboard Shortcuts (? / Help modal and hotkeys)
    window.addEventListener('keydown', (e) => this.handleKeyboardShortcut(e));

    // 12. Save Current Soundscape to Favorites (for logged in users)
    const saveFavBtn = document.getElementById('btn-save-favorite');
    if (saveFavBtn) {
      saveFavBtn.addEventListener('click', () => {
        if (!this.auth.currentUser) {
          this.openModal('login-modal');
          this.showToast('Please log in or create an account to save favorite soundscapes!', 'info');
          return;
        }

        const favItem = {
          id: `fav-${Date.now()}`,
          datasetId: this.currentDataset.id,
          title: `${this.currentDataset.title} (${this.currentDataset.frameNames[this.currentFrameIndex] || 'Frame ' + (this.currentFrameIndex + 1)})`,
          synth: this.audio.currentSynth,
          scale: this.audio.currentScale,
          savedAt: new Date().toISOString()
        };

        this.auth.saveFavorite(favItem);
        this.showToast(`Saved "${favItem.title}" to your soundscapes!`, 'success');
      });
    }

    // 13. Modals Close Handlers
    document.querySelectorAll('.modal-close, .modal-backdrop').forEach(el => {
      el.addEventListener('click', (e) => {
        const modal = el.closest('.modal');
        if (modal) modal.classList.remove('open');
      });
    });
  }

  /**
   * Set up Authentication & Modals
   */
  setupAuthListeners() {
    // Header Auth Buttons
    const btnOpenLogin = document.getElementById('btn-open-login');
    const btnOpenSignup = document.getElementById('btn-open-signup');
    const btnUserProfile = document.getElementById('btn-user-profile');

    if (btnOpenLogin) btnOpenLogin.addEventListener('click', () => this.openModal('login-modal'));
    if (btnOpenSignup) btnOpenSignup.addEventListener('click', () => this.openModal('signup-modal'));
    if (btnUserProfile) btnUserProfile.addEventListener('click', () => this.openModal('profile-modal'));

    // Switch between login & signup inside modal
    const linkToSignup = document.getElementById('link-to-signup');
    const linkToLogin = document.getElementById('link-to-login');
    if (linkToSignup) {
      linkToSignup.addEventListener('click', (e) => {
        e.preventDefault();
        this.closeModal('login-modal');
        this.openModal('signup-modal');
      });
    }
    if (linkToLogin) {
      linkToLogin.addEventListener('click', (e) => {
        e.preventDefault();
        this.closeModal('signup-modal');
        this.openModal('login-modal');
      });
    }

    // Demo Login Button (Instant 1-click test)
    const btnDemoLogin = document.getElementById('btn-demo-login');
    if (btnDemoLogin) {
      btnDemoLogin.addEventListener('click', () => {
        const res = this.auth.loginAsDemo();
        if (res.success) {
          this.closeModal('login-modal');
          this.showToast(`Welcome back, ${res.user.name}! (NASA Climate Sonification Fellow)`, 'success');
        }
      });
    }

    // Login Form Submit
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
      loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const pass = document.getElementById('login-password').value;
        const errorEl = document.getElementById('login-error');

        const res = this.auth.login(email, pass);
        if (res.success) {
          errorEl.textContent = '';
          this.closeModal('login-modal');
          this.showToast(`Welcome back, ${res.user.name}!`, 'success');
        } else {
          errorEl.textContent = res.error;
        }
      });
    }

    // Sign Up Form Submit
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
      signupForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('signup-name').value;
        const email = document.getElementById('signup-email').value;
        const password = document.getElementById('signup-password').value;
        const preferredSynth = document.getElementById('signup-synth').value;
        const preferredScale = document.getElementById('signup-scale').value;
        const screenReaderAnnounce = document.getElementById('signup-sr-toggle').checked;
        const highContrast = document.getElementById('signup-contrast-toggle').checked;
        const errorEl = document.getElementById('signup-error');

        const res = this.auth.signup({
          name,
          email,
          password,
          preferredSynth,
          preferredScale,
          accessibility: { screenReaderAnnounce, highContrast }
        });

        if (res.success) {
          errorEl.textContent = '';
          this.closeModal('signup-modal');
          this.showToast(`Account created! Welcome to Earth Jukebox, ${res.user.name}.`, 'success');
          // Apply user preference
          this.audio.setSynth(preferredSynth);
          this.audio.setScale(preferredScale);
          if (highContrast) this.a11y.setHighContrast(true);
        } else {
          errorEl.textContent = res.error;
        }
      });
    }

    // Logout Button
    const btnLogout = document.getElementById('btn-logout');
    if (btnLogout) {
      btnLogout.addEventListener('click', () => {
        this.auth.logout();
        this.closeModal('profile-modal');
        this.showToast('You have been logged out.', 'info');
      });
    }

    // Subscribe Auth State changes to update Header & Profile UI
    this.auth.subscribe((user) => this.updateAuthUI(user));
    this.updateAuthUI(this.auth.currentUser);
  }

  updateAuthUI(user) {
    const unauthNav = document.getElementById('nav-unauthenticated');
    const authNav = document.getElementById('nav-authenticated');
    const userAvatar = document.getElementById('header-user-avatar');
    const userName = document.getElementById('header-user-name');

    if (user) {
      if (unauthNav) unauthNav.style.display = 'none';
      if (authNav) authNav.style.display = 'flex';
      if (userAvatar) userAvatar.textContent = user.avatar || user.name.slice(0, 2).toUpperCase();
      if (userName) userName.textContent = user.name;
      this.renderProfileModal(user);
    } else {
      if (unauthNav) unauthNav.style.display = 'flex';
      if (authNav) authNav.style.display = 'none';
    }
  }

  renderProfileModal(user) {
    if (!user) return;
    const profileName = document.getElementById('profile-name');
    const profileRole = document.getElementById('profile-role');
    const profileEmail = document.getElementById('profile-email');
    const favoritesList = document.getElementById('profile-favorites-list');

    if (profileName) profileName.textContent = user.name;
    if (profileRole) profileRole.textContent = user.role || 'Earth Science Explorer';
    if (profileEmail) profileEmail.textContent = user.email;

    if (favoritesList) {
      if (!user.savedSoundscapes || user.savedSoundscapes.length === 0) {
        favoritesList.innerHTML = `<div class="empty-state">No saved soundscapes yet. Explore a dataset and click "Save to Library"!</div>`;
      } else {
        favoritesList.innerHTML = user.savedSoundscapes.map(fav => `
          <div class="favorite-item">
            <div class="fav-info">
              <span class="fav-title">${fav.title}</span>
              <span class="fav-meta">Synth: ${fav.synth} | Scale: ${fav.scale}</span>
            </div>
            <div class="fav-actions">
              <button class="btn-fav-play" data-dataset="${fav.datasetId}" data-synth="${fav.synth}" data-scale="${fav.scale}" title="Play Soundscape">▶ Play</button>
              <button class="btn-fav-delete" data-id="${fav.id}" title="Remove">✕</button>
            </div>
          </div>
        `).join('');

        // Wire play & delete
        favoritesList.querySelectorAll('.btn-fav-play').forEach(btn => {
          btn.addEventListener('click', async () => {
            const dId = btn.getAttribute('data-dataset');
            const synth = btn.getAttribute('data-synth');
            const scale = btn.getAttribute('data-scale');
            this.loadDataset(dId);
            this.audio.setSynth(synth);
            this.audio.setScale(scale);
            document.getElementById('synth-select').value = synth;
            document.getElementById('scale-select').value = scale;
            this.closeModal('profile-modal');
            await this.audio.ensureRunning();
            this.isSonifying = true;
            this.updatePlayButtonState();
          });
        });

        favoritesList.querySelectorAll('.btn-fav-delete').forEach(btn => {
          btn.addEventListener('click', () => {
            const favId = btn.getAttribute('data-id');
            this.auth.removeFavorite(favId);
          });
        });
      }
    }
  }

  /**
   * Set up EIC Datasets List in Sidebar
   */
  setupDatasetList() {
    const listEl = document.getElementById('dataset-list');
    if (!listEl) return;

    listEl.innerHTML = EIC_DATASETS.map((d, idx) => `
      <div class="dataset-card ${idx === 0 ? 'active' : ''}" data-id="${d.id}" role="button" tabindex="0" aria-label="${d.title}">
        <div class="card-header">
          <span class="dataset-num">0${idx + 1}</span>
          <span class="dataset-time">${d.timeRange}</span>
        </div>
        <div class="dataset-card-title">${d.title}</div>
        <div class="dataset-card-sub">${d.subtitle}</div>
        <div class="dataset-tags">
          <span class="tag-mission">${d.mission}</span>
          <span class="tag-synth">${d.audioProfile.defaultSynth}</span>
        </div>
      </div>
    `).join('');

    listEl.querySelectorAll('.dataset-card').forEach(card => {
      card.addEventListener('click', () => {
        const id = card.getAttribute('data-id');
        this.loadDataset(id);
      });
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          this.loadDataset(card.getAttribute('data-id'));
        }
      });
    });
  }

  /**
   * Load & Switch Dataset
   */
  loadDataset(datasetId) {
    const dataset = EIC_DATASETS.find(d => d.id === datasetId) || EIC_DATASETS[0];
    this.currentDataset = dataset;
    this.currentFrameIndex = 0;
    this.visual.clearCustomImage();

    // Update active card styling
    document.querySelectorAll('.dataset-card').forEach(card => {
      card.classList.toggle('active', card.getAttribute('data-id') === dataset.id);
    });

    // Update Audio Presets to match scientific recommendation
    this.audio.setSynth(dataset.audioProfile.defaultSynth);
    this.audio.setScale(dataset.audioProfile.recommendedScale);
    const synthSelect = document.getElementById('synth-select');
    const scaleSelect = document.getElementById('scale-select');
    if (synthSelect) synthSelect.value = dataset.audioProfile.defaultSynth;
    if (scaleSelect) scaleSelect.value = dataset.audioProfile.recommendedScale;

    // Update HUD and Info Displays
    const titleEl = document.getElementById('active-dataset-title');
    const subEl = document.getElementById('active-dataset-sub');
    const missionEl = document.getElementById('active-mission-info');
    const scientificInsightsEl = document.getElementById('dataset-insights');
    const colorLegendEl = document.getElementById('color-legend-bar');

    if (titleEl) titleEl.textContent = dataset.title;
    if (subEl) subEl.textContent = dataset.subtitle;
    if (missionEl) missionEl.textContent = `Mission: ${dataset.mission} | Instrument: ${dataset.instrument}`;

    if (scientificInsightsEl) {
      scientificInsightsEl.innerHTML = dataset.scientificInsights.map(fact => `
        <li class="insight-item"><span class="insight-bullet">✦</span> ${fact}</li>
      `).join('');
    }

    if (colorLegendEl) {
      colorLegendEl.innerHTML = `
        <div class="legend-header"><span>${dataset.units}</span></div>
        <div class="legend-gradient" style="background: linear-gradient(to right, ${dataset.colorLegend.map(c => c.color).join(', ')})"></div>
        <div class="legend-labels">
          ${dataset.colorLegend.map(c => `<span>${c.label}</span>`).join('')}
        </div>
      `;
    }

    // Update Frame Slider Max
    const frameSlider = document.getElementById('frame-slider');
    if (frameSlider) {
      frameSlider.min = 0;
      frameSlider.max = dataset.totalFrames - 1;
      frameSlider.value = 0;
    }

    this.updateFrameDisplay();

    this.a11y.announce(`Loaded ${dataset.title}. Suggested synth: ${dataset.audioProfile.defaultSynth}. Suggested scale: ${dataset.audioProfile.recommendedScale}.`);
    this.auth.addHistory(`Explored ${dataset.title}`);
  }

  /**
   * Update Frame display and text narrative
   */
  updateFrameDisplay() {
    const frameLabel = document.getElementById('current-frame-label');
    const frameCount = document.getElementById('frame-counter');
    const narrativeEl = document.getElementById('frame-narrative-text');

    const total = this.currentDataset.totalFrames || 1;
    const name = this.currentDataset.frameNames[this.currentFrameIndex] || `Frame ${this.currentFrameIndex + 1}`;

    if (frameLabel) frameLabel.textContent = name;
    if (frameCount) frameCount.textContent = `${this.currentFrameIndex + 1} / ${total}`;

    const text = this.currentDataset.narrative(this.currentFrameIndex);
    if (narrativeEl) narrativeEl.textContent = text;

    if (this.a11y.isTTSActive) {
      this.a11y.speak(text, true);
    }
  }

  stepFrame(delta) {
    const total = this.currentDataset.totalFrames || 1;
    this.currentFrameIndex = (this.currentFrameIndex + delta + total) % total;
    const slider = document.getElementById('frame-slider');
    if (slider) slider.value = this.currentFrameIndex;
    this.updateFrameDisplay();
  }

  toggleFrameAnimation() {
    this.isPlayingFrames = !this.isPlayingFrames;
    const btn = document.getElementById('btn-toggle-animation');
    if (btn) {
      btn.innerHTML = this.isPlayingFrames ? '⏸ Pause Time-Lapse' : '▶ Play Time-Lapse';
      btn.classList.toggle('playing', this.isPlayingFrames);
    }

    if (this.isPlayingFrames) {
      this.frameTimer = setInterval(() => {
        this.stepFrame(1);
      }, this.frameSpeedMs);
    } else {
      if (this.frameTimer) clearInterval(this.frameTimer);
    }
  }

  updatePlayButtonState() {
    const btn = document.getElementById('btn-play-sonification');
    const playIndicator = document.getElementById('play-indicator');
    if (btn) {
      btn.classList.toggle('active', this.isSonifying);
      btn.innerHTML = this.isSonifying
        ? '<span class="icon-pulse"></span> Stop Sonification'
        : '<span class="icon-play">▶</span> Start Sonification';
    }
    if (playIndicator) {
      playIndicator.textContent = this.isSonifying ? 'LIVE SONIFICATION' : 'AUDIO PAUSED';
      playIndicator.className = this.isSonifying ? 'status-pill live' : 'status-pill paused';
    }
  }

  /**
   * Handle Custom Image Upload
   */
  handleCustomImageUpload(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        this.visual.setCustomImage(img);
        this.showToast(`Custom satellite image "${file.name}" loaded for sonification!`, 'success');
        this.a11y.announce(`Loaded custom image ${file.name}. Computer vision sonification ready.`);
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  }

  /**
   * Toggle Live Audio Recording
   */
  async toggleRecording() {
    const recordBtn = document.getElementById('btn-record-audio');
    const recordTimer = document.getElementById('record-timer');

    if (!this.audio.isRecording) {
      await this.audio.ensureRunning();
      const started = this.audio.startRecording();
      if (!started) {
        this.showToast('Unable to start recording. Please ensure audio is playing.', 'error');
        return;
      }

      this.recordingSeconds = 0;
      if (recordBtn) {
        recordBtn.classList.add('recording');
        recordBtn.innerHTML = '<span class="rec-dot"></span> Stop & Save Recording';
      }

      this.recordingInterval = setInterval(() => {
        this.recordingSeconds++;
        const mins = String(Math.floor(this.recordingSeconds / 60)).padStart(2, '0');
        const secs = String(this.recordingSeconds % 60).padStart(2, '0');
        if (recordTimer) recordTimer.textContent = `${mins}:${secs}`;
      }, 1000);

      this.showToast('Live sonification recording started!', 'info');
    } else {
      clearInterval(this.recordingInterval);
      const res = await this.audio.stopRecording();

      if (recordBtn) {
        recordBtn.classList.remove('recording');
        recordBtn.innerHTML = '<span class="rec-dot"></span> Record Sonification';
      }
      if (recordTimer) recordTimer.textContent = '00:00';

      if (res && res.url) {
        // Trigger download
        const a = document.createElement('a');
        a.href = res.url;
        a.download = `NASA-Earth-Jukebox-${this.currentDataset.id}-${Date.now()}.webm`;
        a.click();
        this.showToast('Recording complete! File downloaded.', 'success');
        this.auth.addHistory(`Recorded sonification for ${this.currentDataset.title}`);
      }
    }
  }

  /**
   * Keyboard Shortcuts Handler
   */
  handleKeyboardShortcut(e) {
    // Skip if typing in an input field
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) return;

    switch (e.key) {
      case ' ':
        e.preventDefault();
        document.getElementById('btn-play-sonification').click();
        break;
      case 'ArrowLeft':
        e.preventDefault();
        this.stepFrame(-1);
        break;
      case 'ArrowRight':
        e.preventDefault();
        this.stepFrame(1);
        break;
      case 'm':
      case 'M':
        document.getElementById('btn-mute').click();
        break;
      case 'r':
      case 'R':
        this.toggleRecording();
        break;
      case '?':
      case 'h':
      case 'H':
        this.openModal('help-modal');
        break;
    }
  }

  openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('open');
      const firstInput = modal.querySelector('input, button');
      if (firstInput) firstInput.focus();
    }
  }

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('open');
  }

  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <span class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '⚠' : 'ℹ'}</span>
      <span class="toast-message">${message}</span>
    `;

    container.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('fade-out');
      setTimeout(() => toast.remove(), 400);
    }, 4000);
  }
}

// Instantiate on DOM load
window.addEventListener('DOMContentLoaded', () => {
  window.earthApp = new EarthJukeboxApp();
});
